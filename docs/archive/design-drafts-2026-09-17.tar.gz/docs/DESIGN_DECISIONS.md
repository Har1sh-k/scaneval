# SASTbench — Design Decisions & Brainstorm

A running scratchpad for design decisions, open problems, and improvements to
SASTbench. Entries are appended as they come up; nothing here is final until it
lands in code or in `README.md`.

---

## 1. Contamination control: leakage paths and cutoff gating

### Fix the current leakage paths first

The Full Track currently scans the live checkout directly in `scripts/run.py:222`.
Those checkouts are normal clones retaining `.git`, and their directory names
contain the repository identity and commit prefix (`scripts/setup_repos.py:23`).

For every trial, I would:

1. Treat `.repos` as an immutable cache.
2. Export the selected commit into a fresh randomly named directory.
3. Remove `.git`, repository name, case ID, commit SHA, CVE/GHSA strings,
   advisory links, and benchmark metadata.
4. Mount only that directory read-only.
5. Clear conversations, indexes, caches, and scanner state.
6. Enforce offline networking, except an allowlisted model API endpoint when
   required.
7. Hash the exact input tree and store the transformation manifest.

Also:

- PR-mode adapters currently receive the full case object, including secret
  ground truth such as CVE IDs and expected regions (`scripts/pr_runner.py:242`).
  Adapters should receive only a sanitized runtime case.
- `--model` currently selects a knowledge cutoff; it does **not** select the
  inference model (`scripts/run.py:402`). Bind and verify the actual model
  against the cutoff entry. There is currently no Qwen adapter or Qwen registry
  entry.

### Cutoff gating is a date-based exclusion rule, not a memory detector

For each model, define:

- **C_m** — the model's declared knowledge cutoff.
- **H_i** — the earliest known public artifact that reveals the answer for case *i*.

Conceptually:

```
H_i = min(public fix, security PR/issue, GHSA, CVE, PoC, ...)
```

Then:

```
include case  ⟺  H_i > C_m
```

### Concrete example

`cases/full/real_world_disclosed/SB-TS-RW-001/case.json:32` has:

- Fix date: December 30, 2025
- GHSA publication: January 13, 2026
- Earliest answer-bearing date: December 30, 2025

Therefore:

| Model cutoff     | Gate result | Meaning                                                |
| ---------------- | ----------- | ------------------------------------------------------ |
| May 31, 2025     | Include     | No recorded public answer existed before the cutoff     |
| January 31, 2026 | Exclude     | The fix and advisory could have entered training        |

Notice what this does **not** say. Inclusion does not prove the model never saw
the vulnerable repository. It only says we found no public fix/advisory before
the cutoff.

### Three different kinds of knowledge

It helps to separate:

1. **Generic security knowledge** — the model understands SQL injection, path
   traversal, SSRF, and similar patterns. This is legitimate generalization.
2. **Code familiarity** — the model may have encountered that repository or
   source file during training, before the vulnerability was discovered.
3. **Answer-bearing exposure** — the model may have seen a patch, advisory,
   issue, PR, or PoC that connects the exact code to the vulnerability.

Cutoff gating mainly reduces the third risk. It cannot tell whether a particular
output came from internal memory or fresh code analysis.

### What the literature says

Research supports temporal gating as a useful risk reduction, but not as proof of
cleanliness.

[Roberts et al., ICLR 2024](https://proceedings.iclr.cc/paper_files/paper/2024/hash/2d04d97593c8c33d415337f408ed0e1b-Abstract-Conference.html)
used model cutoffs as a natural experiment on programming problems. Performance
was related to whether pre-cutoff problems appeared frequently on GitHub. That is
evidence consistent with contamination, but it is aggregate evidence — not proof
about one answer.

[LiveCodeBench](https://arxiv.org/abs/2403.07974) reduces exposure risk by
continually adding programming problems published after model cutoffs. However,
temporal effects differed across problem sources, showing that time, difficulty,
duplication, and benchmark construction interact.

[LiveBench](https://openreview.net/forum?id=sKYHBTAxVa) uses frequent updates and
temporarily private questions. Importantly, it calls itself
*contamination-limited*, not *contamination-free*. That is appropriate language
for SASTbench too.

The strongest warning comes from
[Test of Time, ACL 2026](https://aclanthology.org/2026.acl-long.1693/). The
researchers found that apparent pre/post-cutoff performance patterns could change
when they changed how questions were constructed — even while preserving the
underlying source material or programming solution:

- Cloze-style questions showed temporal decay.
- Generated questions from the same papers generally did not.
- Light transformations of LiveCodeBench problems greatly weakened the original
  temporal pattern.

So these inferences are invalid:

- "Performance fell after the cutoff, therefore earlier success was memorization."
- "Performance did not fall, therefore the model is uncontaminated."

Question wording can affect whether stored information is easily recalled. Cutoff
analysis therefore needs additional controls.

### Problems with the current SASTbench gate

The implementation in `scripts/cutoff.py:53` currently uses only:

- `fixCommitDate`
- `ghsaPublished`
- `cvePublished`

There are several limitations:

- `fixCommitDate` is the Git committer timestamp, not necessarily when the commit
  became public.
- Earlier public issues, PRs, release notes, blogs, and PoCs are not tracked.
- Missing dates currently pass the gate.
- Most model cutoff records are unverified estimates.
- `--model` selects only the cutoff profile; it does not select or verify the
  actual inference model in `scripts/run.py:402`.

That last point means a run could apply an Opus cutoff while actually invoking
Sonnet — or even a non-LLM scanner.

### The defensible interpretation

I would report three states:

- **cutoff-eligible** — earliest known answer artifact is after the cutoff.
- **cutoff-ineligible** — an answer artifact existed on or before the cutoff.
- **cutoff-unknown** — dates or model provenance are insufficient.

The scientific claim should be:

> Cutoff gating lowers the risk that the model learned the publicly documented
> vulnerability or fix before evaluation.

It should not be:

> This proves the vulnerability was found through code analysis rather than
> memory.

---

## 2. Attribution: what you can classify

| Label                 | Required evidence |
| --------------------- | ----------------- |
| `retrieval-observed`  | Relevant advisory/search content entered model context before the finding. |
| `retrieval-dependent` | Web-enabled runs improve detection reproducibly over matched offline runs. |
| `analysis-supported`  | Vulnerable code is flagged, fixed code is not, and a complete source→guard/carrier→sink evidence path reached the model. |
| `analysis-robust`     | The result survives validated renaming or de-identification. |
| `recall-suspected`    | Offline, sanitized input still produces exact non-inferable CVE/fix facts, especially when performance drops on de-identified variants. |
| `unattributed`        | A hit occurred, but available evidence cannot identify its source. |

Exact offline CVE recall is strong evidence of prior knowledge, but it still does
not prove that recall *caused* the finding.

---

## 3. Popularity / exposure as a contamination signature

### What the proposal is trying to test

The intuition is:

- Popular benchmark items are more likely to appear repeatedly in training data.
- For items published before the model cutoff, greater exposure might therefore
  predict better detection.
- For post-cutoff items, later popularity should not help an offline model
  because those items supposedly could not have entered training.

The expected "contamination signature" is therefore:

| Popularity–detection relationship                | Interpretation |
| ------------------------------------------------ | -------------- |
| Positive before cutoff, approximately zero after | Consistent with training exposure |
| Positive both before and after                   | Likely difficulty, repository characteristics, retrieval, or another confounder |
| Zero in both groups                              | No detected signature; not proof of cleanliness |
| Positive only after cutoff                       | Suspect cutoff mismatch, post-training exposure, web retrieval, or dataset shift |

### What Roberts actually measured

Roberts did not use repository stars. Their "GitHub Presence" was approximately
the number of times the exact Codeforces or Project Euler problem appeared across
GitHub repositories, based on occurrences of its title or ID. They even counted
multiple occurrences within one repository.

Their model was essentially:

```
performance ~ (difficulty + log(GitHub presence)) × post-cutoff
```

They found that GitHub presence predicted GPT-4's Codeforces performance before
the cutoff but not afterward. For GPT-4, the odds ratio was approximately 1.044
before versus 1.000 after. Results for other models were less decisive, and the
authors explicitly acknowledged possible confounding.
([Roberts et al., ICLR 2024](https://proceedings.iclr.cc/paper_files/paper/2024/file/2d04d97593c8c33d415337f408ed0e1b-Paper-Conference.pdf))

So:

- Repository stars = general project prominence.
- Roberts's GitHub Presence = frequency of the particular evaluated item.

Those are related but materially different measurements.

### Why stars are currently weak for SASTbench

The present disclosed dataset contains 156 cases but only 10 repositories:

- OpenClaw: 55
- n8n: 42
- Flowise: 31
- Remaining seven repositories: 28

Therefore, stars provide only 10 independent popularity values. Treating 156
cases — or hundreds of repeated Qwen runs — as 156 independent popularity
observations would be pseudoreplication.

Repeated runs improve the estimate of each case's detection probability. They do
not create more independent repositories or popularity measurements.

The temporal balance is also poor for most existing cutoffs:

- June 2024: 1 pre / 155 post
- May 2025: 5 pre / 151 post
- August 2025: 7 pre / 149 post
- January 2026: 40 pre / 116 post

Only the January 2026 split is remotely usable, and it still has only ten
repository clusters.

There is also an implementation issue: the current cutoff handling removes
pre-cutoff cases before scanning in `scripts/run.py:197`. A longitudinal analysis
needs to run all cases and label them pre/post during analysis, rather than gating
one side away.

### The correct SASTbench analogue

You should measure two different exposure concepts:

1. **Source-code familiarity**
   - Historical stars and forks.
   - Number of mirrors or repositories containing the vulnerable function/code
     fingerprint.
   - When the vulnerable code first became public.

2. **Known-vulnerability exposure**
   - Occurrences of the fix, security PR, issue, GHSA/CVE, advisory, or PoC.
   - When the first answer-bearing artifact became public.

Stars are a coarse secondary proxy for the first. They say very little about
whether the model memorized the specific vulnerability or CVE.

The stronger case-level variable would be something like:

```
case exposure = log(1 + number of distinct repositories
                        containing the code/advisory fingerprint)
```

The query, corpus, collection date, deduplication rules, and historical window
must be frozen and recorded.

### The statistical correction

Do not rely on two separate regressions and say:

> Significant before, nonsignificant after, therefore the slopes differ.

That conclusion is statistically invalid. Test the difference directly using an
interaction:

```
logit P(correct detection) = α
                           + β₁·exposure
                           + β₂·post
                           + β₃·(exposure × post)
                           + controls
```

The key quantity is **β₃**: does the exposure relationship materially weaken after
the cutoff?

The analysis should also control for language, CWE, repository size,
relevant-file count, cross-file/dataflow span, context size, and case difficulty,
with clustering by case, vulnerable snapshot, and repository.

### My corrected version of the proposal

> Add a Roberts-inspired, case-level exposure analysis. Measure reproducible
> GitHub frequency for each vulnerable code pattern separately from advisory/CVE
> frequency, then test whether the relationship between exposure and correct
> detection is attenuated after the model cutoff. Treat repository stars as a
> descriptive sensitivity variable rather than the primary exposure measure.

A stars plot and pilot regression could be done in an evening. A credible
empirical result requires more independent repositories, better pre/post balance,
repeated Full/LLM results, historical exposure measurements, difficulty controls,
and a direct interaction test. If successful, the conclusion would be "consistent
with training exposure," not proof that any particular answer came from memory.

---

## 4. The core experiment: matched conditions and de-identification

### The core experiment

For every vulnerability, create these isolated conditions:

| Condition                 | Input | What it tests |
| ------------------------- | ----- | ------------- |
| Original vulnerable       | Original code, no history/web                   | Baseline performance |
| Original fixed            | Same tree plus only the security patch          | Whether the model distinguishes vulnerable from safe code |
| De-identified vulnerable  | Same vulnerability, repository identity removed | Whether detection survives without recognition cues |
| De-identified fixed       | Identically transformed fixed version           | Controls for false positives introduced by transformation |
| Identity-only probe       | Repository/version/path names, but no code      | Whether the model can recall the CVE directly |

Every condition gets a fresh conversation, empty cache, identical tools and
budget, and randomized execution order.

### How to interpret it

Let detection probability be measured over repeated runs.

- High detection on de-identified-vulnerable and low detection on
  de-identified-fixed strongly supports code-based analysis.
- Original-vulnerable succeeds but de-identified-vulnerable fails: identity or
  memorized lexical cues are helping.
- Identity-only condition produces the exact CVE/GHSA: strong evidence of
  explicit recall, assuming web and local history are unavailable.
- Both code-only and identity-only succeed: mixed capability — the model may know
  the case but can also analyze it.
- Vulnerable and fixed versions are both flagged: likely pattern matching,
  repository prior, or false-positive behavior.
- A trace shows the model read an advisory, fix history, or web result: classify
  it as retrieval-assisted, not internal recall.

None of these proves what happened inside the neural network, but together they
make some explanations much more plausible than others.

### The vulnerable–fixed pair must be tightly matched

Do not simply compare the vulnerable commit with the repository's later fix commit
if that commit includes unrelated changes.

A cleaner pair is:

1. Export the vulnerable commit.
2. Extract only the security patch.
3. Apply that patch to a copy of the vulnerable tree.
4. Use those as the vulnerable and fixed pair.

Both trees should otherwise be identical. Run build/tests and a security
regression test to verify that:

- Normal functionality remains equivalent.
- The exploit succeeds only in the vulnerable version.
- The expected vulnerable regions differ only where necessary.

This is one of the strongest controls. If the model really analyzes the dataflow,
changing the relevant validation or sink should change its conclusion.

### What "de-identified" should mean

Use several levels rather than one large transformation:

1. **Environment de-identification**
   - Random directory name.
   - No `.git`.
   - No case ID or commit SHA in paths.
   - No benchmark metadata.

2. **Metadata de-identification**
   - Remove repository URLs, package author fields, badges, README history and
     changelogs.
   - Remove CVE/GHSA/advisory references and security comments.
   - Replace project/package name with a neutral name.

3. **Lexical de-identification**
   - Consistently rename internal functions, classes, variables and internal
     filenames.
   - Preserve public APIs, framework conventions and security-relevant string
     values when changing them could alter behavior.

Apply exactly the same renaming map to the vulnerable and fixed variants. Validate
every transformed tree by building and running tests.

One variant is not enough because renaming can accidentally make the program
harder. Two or three independently renamed variants let you estimate that
transformation effect.

---

## 5. Multi-file vulnerabilities: scoring detection vs. evidence coverage

I would not make "opened every expected file" part of the correctness score. That
can be gamed and could punish an efficient search.

Instead, record separate metrics:

- Did the model access the source, propagation and sink files?
- Were the relevant lines actually delivered to its context?
- Did its report cite the complete cross-file chain?
- Is the final finding correct despite incomplete trace coverage?

For full "code-grounded" credit, require the report to identify enough evidence to
establish the vulnerable flow. Keep raw detection accuracy and evidence coverage
as separate scores.

---

## 6. Recommended primary measurements

For every case, report:

- Vulnerable detection rate.
- Fixed-version false-positive rate.
- De-identified vulnerable detection rate.
- De-identified fixed false-positive rate.
- Exact-ID accuracy in the identity-only probe.
- Relevant-file evidence coverage.
- Forbidden-access and network-access counts.

The strongest analysis measurement is approximately:

```
code sensitivity = P(hit | de-identified vulnerable)
                 − P(hit | de-identified fixed)
```

An identity contribution can be estimated by comparing that difference with the
corresponding original-code difference.

This design will let you label results as:

- analysis-supported
- recall-supported
- retrieval-assisted
- mixed
- unresolved

---

## 7. External review, round 1: four claims that need correction

> Verdict: most of this is a meaningful improvement. Keep the tiering, identity
> probe, matched patch pairs, validation levels, region remapping, and
> language-specific de-identification. Four claims need correction.

### 7.1 Current scoring does not establish a complete flow

The statement about `mustDetectRegionIds` is too strong.

Currently, the scorer checks only:

- Finding path/range overlaps a region.
- Finding kind is accepted.
- Every required region ID received a matching finding.

That happens in `scripts/scoring.py:127`. It does **not** verify that one report
explains a connected source→propagation→sink chain. Findings have only one
location and a free-form message in `schema/results.schema.json:193`; regions have
no flow role or edges in `schema/case.schema.json:141`.

Additionally:

- Only 2 of 156 disclosed cases have multiple required region IDs.
- Only one case has annotated regions spanning multiple files.
- Those regions generally describe separate affected endpoints or
  implementations, not one causal chain.

Therefore, the accurate statement is:

> Current scoring deterministically measures kind-compatible required-region
> coverage. Structured flow annotations are needed before calling it complete
> cross-file grounding.

You can still avoid an LLM judge by adding:

```
flowId
evidenceRegionId
role: source | propagation | missing_guard | sink
requiredEdges
```

The scanner report should then return structured `evidence[]` references and flow
edges. Report these separately:

- Raw vulnerability detection.
- Required-region coverage.
- Complete-chain grounding.
- Citation precision.

There is also an existing scoring-unit problem worth fixing first: true positives
count **findings**, while false negatives count **unique required regions**.
Duplicate findings can therefore inflate recall because TP increments per finding
(`scripts/scoring.py:143`) but FN increments per missing region
(`scripts/scoring.py:163`).

### 7.2 Patch-backported trees are excellent — but not uncontaminatable

Keep the construction, but use this wording:

> The backport produces an unpublished matched snapshot, preventing trivial
> exact-snapshot recognition and removing unrelated changes from the real fix
> commit.

The exact tree is novel, but its components may not be:

- The vulnerable base may have been in training.
- The public patch may have been memorized.
- The advisory may have been memorized.
- The security pattern is not novel.

So it reduces exact-instance contamination; it does not eliminate contamination by
construction.

For fixed variants, do more than shift line numbers. Define a stable semantic
target:

- Original enclosing function or AST symbol.
- Replacement guard or patch hunk.
- Variant-specific path/range.
- Status such as `replaced`, `moved`, or `deleted`.

The fixed version should be a negative control **for the same root cause**.
Unrelated vulnerabilities elsewhere in the repository should not automatically
count as fixed-tree false positives.

### 7.3 Identity probing is a temporal-knowledge audit

This is one of the best additions, but I would not call it direct cutoff
verification.

If an isolated offline model correctly volunteers a CVE/GHSA first published well
after its claimed cutoff, you have shown:

> Post-cutoff information is accessible to the evaluated runtime.

That means at least one assumption failed:

- Wrong registry cutoff.
- Wrong actual model/snapshot.
- Later post-training or fine-tuning.
- Provider-side enrichment.
- Experimental leakage.
- Incorrect artifact publication date.

It does not uniquely prove which one failed. Therefore, use statuses such as:

- `temporal-inconsistency-detected`
- `no-temporal-inconsistency-detected`
- `inconclusive`

Keep registry source verification separate from behavioral auditing. A
vendor-sourced cutoff can remain `sourceVerified: true` while receiving
`behavioralAudit: inconsistent`.

The proposed two probes are good:

- **Blind:** repository plus version/commit.
- **Targeted:** repository, version and path.

Do not provide the vulnerability description, CWE, fix commit or candidate
identifier. Require at most one CVE and one GHSA, or `UNKNOWN`. Add:

- Old pre-cutoff positive controls.
- Unaffected-version and decoy-path controls.
- A 30–90-day cutoff buffer.
- Repeated paraphrases for positive results.
- Exact model ID and snapshot verification.

A correct linked CVE+GHSA pair is particularly strong. A negative response is weak
evidence because failure to recall does not establish absence from training.

### 7.4 The triple difference is honest but currently exploratory

The logic is valid:

1. Measure vulnerable–fixed discrimination.
2. Compare original versus de-identified identity.
3. Compare that identity advantage before versus after cutoff.

Conceptually:

```
R = identity_advantage(pre) − identity_advantage(post)
```

A positive *R* is consistent with extra pre-cutoff identity assistance.

But post-cutoff identity advantage is not automatically a clean estimate of
"legitimate context." That requires strong assumptions:

- Pre/post cases have comparable difficulty and vulnerability types.
- Identity context has the same legitimate value over time.
- De-identification affects both periods equally.
- No post-cutoff information entered any later training stage.

A better within-case design has three identity levels:

1. Original project identity and domain context.
2. Pseudonymous project identity while preserving domain context.
3. Strong lexical/structural de-identification.

Then:

- Original vs pseudonymous measures unique repository-name cues.
- Pseudonymous vs strong de-identification measures the analytical cost of
  removing domain terminology.

That is cleaner than making the temporal triple difference carry the entire
identification argument.

Current data also constrain it:

- January 2026 cutoff: 40 pre / 116 post, with 7 repositories spanning both.
- Earlier cutoffs: only 1–7 pre-cutoff cases.

Therefore, a 30-case gold subset can support the paired identity experiment, but
only an *exploratory* triple-difference analysis for a January 2026 cutoff. An
earlier-cutoff Qwen model would require substantially more older cases and
independent repositories.

### 7.5 Tiering and validation

The 40-runs-per-case calculation is correct. Full factorial evaluation should be
restricted to a gold subset.

1. **All eligible cases**
   - Original vulnerable baseline.
   - Blind and targeted identity probes.
   - Fixed pair only where the patch can be constructed and validated reliably.

2. **Gold subset, initially 24–30 cases**
   - Original vulnerable/fixed.
   - Pseudonymous vulnerable/fixed.
   - Strongly de-identified vulnerable/fixed.
   - Full semantic validation.

3. **Pilot first**
   - Run 8–10 gold cases at k=3.
   - Estimate run variance, failure rates and cost.
   - Simulate the required number of cases and repetitions.
   - Do not assume k=5 in advance.

For validation, explicit levels make sense:

- **V1:** patch applies and transformation manifest matches.
- **V2:** affected files parse and AST changes are allowed.
- **V3:** targeted regression/exploit distinguishes vulnerable from fixed.
- **V4:** full build and relevant tests pass.

Only V3/V4 pairs should support strong `analysis-supported` or fixed-version
false-positive labels. Also, `tsc --noEmit` is not merely a parse check — it
generally requires project dependencies.

**Overall verdict:** the revised design is strong once "grounded scoring,"
"uncontaminatable," and "cutoff falsification" are softened. The best immediate
additions are the standalone temporal-knowledge probe, pseudonymous middle
condition, deterministic flow-evidence schema, and validation tiers.

---

## 8. External review, round 2: revisions after checking the checkout

> I agree with the core design and would use it for a pilot. Rereading it, I would
> tighten a few of my earlier claims before making it the benchmark specification.

**1. Fix the scoring units first.** Verified the bug: ten duplicate findings on
one of two required regions produce 90.9% reported recall, although
required-region coverage is 50%. Recall should count *distinct required targets
detected*, with duplicate findings handled separately. The relevant logic is in
`scripts/scoring.py:127`.

Structured evidence would help, but matching reported nodes and edges to
annotations establishes agreement with the annotated *explanation*. It still
cannot establish how the model arrived at that explanation. Have models cite
paths, spans and relationships; keep benchmark region IDs hidden and let the
evaluator perform the mapping.

**2. A backport is not necessarily an unpublished tree.** If the security patch
was the only upstream change, applying it might reproduce the public fixed
snapshot exactly. Even a novel whole-tree hash says little about whether the
relevant function was memorized.

The strongest reason for backporting is *experimental control*: vulnerable and
fixed inputs differ only in the changes needed to address the target flaw. Use the
existing fixed snapshot when it already satisfies that condition.

**3. Identity probing gives evidence of available knowledge, not evidence that it
caused a finding.** Repeatedly recovering the correct identifier and its
relationship to the affected version is useful evidence. One correct response can
still be a guess, and one failure can be a recall failure.

There is another scoring detail: a blind repository/version prompt can
legitimately return several different advisories. Returning a *different, valid*
advisory must not be classified as hallucination merely because it differs from
your selected case. Score repository knowledge and recognition of the specific
case separately. Run these probes in independent sessions so their answers cannot
prime the code evaluations.

**4. The comparisons measure behavioral effects more cleanly than "recall versus
reasoning."** A model can remember a patch and correctly distinguish vulnerable
from fixed code. It can also analyze code while remembering the repository.

| Comparison                            | Defensible measurement |
| ------------------------------------- | ---------------------- |
| Vulnerable versus fixed               | Sensitivity to the security-relevant code change |
| Original versus pseudonymous          | Effect of removing the selected identity cues |
| Pseudonymous versus stronger renaming | Sensitivity to that additional transformation |
| Identity-only probe                   | Ability to recover a known advisory association |

Strong renaming can change difficulty, tokenization and recall cues
simultaneously. Its effect cannot be attributed entirely to lost domain context.
Test of Time demonstrates why this matters: changing question construction altered
temporal contamination signals while preserving the underlying material.
(Attributed by the reviewer as Zhang et al., ACL 2026 — see the citation note in
section 1.)

**5. Make the validation levels cumulative.** As written, V4 could mean "the
ordinary test suite passes" without ever checking the target flaw. That is
insufficient. V3 should require a targeted security regression or independently
checked security invariant. V4 should mean V3 *plus* the relevant build and
broader tests. A working exploit is not necessary. Also, explicitly record failed
or unavailable pairs; restricting evaluation to patches that backport easily
creates a selection bias.

**6. Update the cost calculation and treat the sample sizes as provisional.** The
revised design has three identity levels and two code states: six conditions,
assuming one realization of each identity level. At five repetitions, that is 30
scans per case, rather than the earlier eight-condition design's 40.

A ten-case pilot at three repetitions would therefore require 180 scans per model,
plus probes. That is a reasonable starting budget for learning about costs and
variability; it does not establish statistical power. Select cases before seeing
model performance, account for repository clustering, and retain pre-cutoff cases
in the research dataset even when they are excluded from the primary benchmark
score.

**Closing:** make validated vulnerable–fixed discrimination and identity-probe
performance the first study's primary measurements. Apply pseudonymization to the
curated subset, and keep the triple difference exploratory until the dataset has
enough independent repositories and cases on both sides of the cutoff.

---

## 9. A better direction: make the answer depend on a fresh, controlled change

> Framing: does a correct finding depend on examining the supplied code, or was
> knowing the repository/CVE enough? The proposal below tries to make the correct
> answer depend on a fresh, controlled change in the program, giving a measurable
> test of whether the model responds to the *current* code.

### 9.1 Make some answers impossible to recover from the historical CVE alone

Alongside real CVE cases, introduce a small collection of private test
applications with precisely defined security requirements. Generate each instance
*after* fixing the model snapshot.

For example, a small application could distribute an authorization decision across
three files:

- One selects an operation.
- Another selects the policy used for that operation.
- A third implements that policy.

Randomize the connections while keeping the names, formatting and overall
structure comparable. Some combinations satisfy the stated security requirement;
others violate it. An independent checker determines the expected answer.

The useful property is that the final connections were chosen *for this
evaluation*. Knowing a public vulnerability or recognizing a familiar function
cannot, by itself, determine this instance's answer.

In a balanced experiment without accidental clues, a model ignoring the
instance-specific information cannot outperform chance. Success supports
dependence on the supplied information. It still does not establish a particular
internal reasoning mechanism.

Counterfactual evaluation has precedent: *Reasoning or Reciting?* tests whether
models can adapt when familiar task assumptions change. Applying that principle to
these small security examples would be our proposed adaptation.
([Wu et al., NAACL 2024](https://arxiv.org/abs/2307.02477))

### 9.2 Add harmless edits as a control — the cheapest major improvement

The previous design mostly asked whether the answer *changes* after a fix. We also
need to ask whether it *stays correct* after an irrelevant change.

Use four matched versions:

| Version | Target security condition | Other change            | Expected finding |
| ------- | ------------------------- | ----------------------- | ---------------- |
| A       | Flaw present              | None                    | Report target flaw |
| B       | Flaw corrected            | None                    | Do not report target flaw |
| C       | Flaw present              | Validated harmless edit | Report target flaw |
| D       | Flaw corrected            | Same harmless edit      | Do not report target flaw |

This tests two properties together: sensitivity to the security change and
stability under irrelevant changes. Present versions independently, without
identifying their condition or showing the pair together.

The harmless edit must actually preserve behavior, and filenames or formatting
must not reveal the label. Apply comparable transformations to both vulnerable and
fixed versions.

Report the rate of correctly judging **both** members of a security pair, plus
correctness across the harmless variants. An always-alarm model and an
always-silent model both fail the paired criterion. PrimeVul already establishes a
useful precedent for scoring vulnerable and patched functions together.
([Ding et al., ICSE 2025](https://arxiv.org/abs/2403.18624))

### 9.3 Test whether the evidence was sufficient — not just whether files were mentioned

The multi-file concern from section 5 matters. A stronger diagnostic is to
construct two applications whose *visible* files are identical but whose decisive
supporting file makes their security outcomes different.

Evaluate three situations:

- All necessary code is available in the vulnerable instance.
- All necessary code is available in the safe instance.
- The decisive supporting information is explicitly unavailable.

For the third situation, the appropriate conclusion is that the target claim
**cannot be determined** from the available evidence, and the model should explain
which missing relationship would resolve it.

This only works when we have verified that the visible information truly permits
both outcomes. Simply deleting an arbitrary file does not establish that.

It gives a direct test of unsupported certainty. A report confidently repeating
the same diagnosis despite missing decisive information is less trustworthy, even
if it happens to match the hidden answer. That observation alone would not prove
recall.

### 9.4 Separate finding the relevant code from judging it

A failed repository scan could mean the model never found the relevant files. That
can look like poor reasoning — or become confused with the benefits of repository
familiarity.

For a selected subset, compare:

- The full repository.
- A curator-selected bundle containing the necessary code and ordinary surrounding
  context, with no diagnosis or answer labels.

If the model succeeds with the bundle but fails on the repository, that points
toward navigation, context selection or context handling as a bottleneck. If it
fails both, supplying the right code was insufficient.

This also makes early experiments cheaper: validate the semantic comparisons using
small bundles before spending heavily on full agent runs. Keep bundle results
distinct from the main repository benchmark, because providing relevant context
makes the task easier.

### 9.5 Calibrate the memory indicators using deliberately known exposure

The strongest additional research idea, if you can experiment with an open-weight
model.

Use private, harmless benchmark examples and randomly assign which examples are
included in a controlled training stage. Keep other examples withheld, and test
both groups using the proposed recall probes and code comparisons.

Now you know which examples were deliberately exposed. You can measure:

- Whether your identity probe detects that exposure.
- How often it misses exposed examples.
- How often it incorrectly flags withheld examples.
- Whether exposure improves task performance or merely identifier recall.

Controlling exposure this way has a stronger basis than inferring it from
popularity. Magar and Schwartz demonstrated that models can memorize contaminated
examples without necessarily benefiting from that memorization on the downstream
task. Their experiments used BERT, so transferring the method would require its
own validation.
([Magar & Schwartz, ACL 2022](https://aclanthology.org/2022.acl-short.18/))

Merely putting an advisory into the prompt would calibrate the effect of *supplied
context*; it would not substitute for this training-exposure experiment.

### 9.6 Priority and pilot budget

Prioritize the four-version experiment (9.2) and the private examples with fresh
security-relevant decisions (9.1). Keep real CVE cases as the practical benchmark,
and use these controlled examples to establish what the measurements mean. The
identity probe remains a useful accompanying audit.

For an initial pilot: ten carefully validated cases × four versions × three
independent runs = 120 trials per model, plus inexpensive identity probes. That is
a starting budget, not a statistically justified final sample size. Use the pilot
to estimate uncertainty and cost, then expand across independent cases and
repositories; many generated variants of one template should not be treated as
many independent discoveries.

The claim to aim for:

> The model correctly tracks security-relevant changes in previously unseen
> instances, remains accurate under harmless changes, and distinguishes sufficient
> from insufficient evidence.

---

## 10. Refocus: this is a SAST product evaluation, not a memorization study

> **My reframing (the important pivot):** I want to keep focus on the SAST
> tool/harness evaluation. There are many SAST vendors — Semgrep and others — so
> as a *buyer*, what do I choose, and what is the benchmark that evaluates that
> harness? Second: if I have built a SAST tool, how do I make an auto-engineering
> loop? To make an auto-engineering or auto-research loop I need the ground truth.
> And on synthetic cases — that is not practical, because we can't keep making and
> reviewing repos, and they don't represent the real-world applications or
> scenarios where SAST tools natively run.

Real-world security regression cases should be the foundation. The
memory-attribution experiments in sections 1–9 become optional research.

The concern about synthetic repositories is reasonable. OWASP itself acknowledges
that most of its benchmark cases are substantially simpler than real applications.
They are useful diagnostic tests, but buyer-facing evidence needs real
repositories and realistic workflows.

### 10.1 For a buyer: evaluate the complete product against their workload

| Buyer's question | What to measure |
| ---------------- | --------------- |
| Will it find security problems relevant to my applications? | Unique known vulnerabilities detected, broken down by framework, language, and vulnerability class |
| Does it distinguish vulnerable code from repaired code? | Detection before the fix, and absence of the same incorrect allegation after the fix |
| How much investigation will its output create? | Reviewed finding precision, duplicate alerts, and measured triage time |
| Does it work across my repositories? | Successful scan coverage, unsupported code, build failures, and timeouts |
| Will it fit our development workflow? | Separate full-repository and PR-review results, including latency and cost |
| Does it add value beyond our current scanner? | Additional confirmed findings and additional review effort |

That last question is especially useful: a buyer may want a *complementary* tool
rather than a replacement.

Run each product in its supported configuration, with the same task and comparable
resource constraints. Record the exact edition, engine, rule pack, model, and
configuration. For example, Semgrep Community Edition and its proprietary
cross-file analysis should be separate evaluated configurations; a CE result does
not characterize the entire commercial offering.

The benchmark can support a purchasing decision, but its conclusion should be
workload-specific. NIST's SATE methodology explicitly emphasizes matching tool
strengths to requirements rather than producing a tool ranking.

### 10.2 For ground truth: curate a known issue inside an existing application

You do not need to build a new repository, or establish that every line of an
existing repository is safe.

For each accepted case, preserve:

- The real affected repository snapshot.
- The real fixed snapshot, where available and sufficiently validated.
- The specific security problem, its relevant assumptions, and acceptable
  reporting locations.
- Evidence supporting the label: maintainer analysis, independent review, and
  available targeted regression tests.

A confirmed issue does not need a CVE. Reviewed internal security fixes can also
become cases.

The crucial distinction is:

> We know whether *this particular issue* exists in these snapshots. Other issues
> in the repository may remain unknown.

This gives three states: **known vulnerable**, **known fixed for this issue**, and
**unknown**.

The current scorer (`scripts/scoring.py:157`) treats every unmatched finding as a
false positive. For real repositories that is unsafe ground truth: a scanner could
discover a genuine additional issue and receive a penalty.

Separate two evaluations:

1. **Known-target evaluation** — automatically measure detection of the curated
   issues and behavior on their fixed counterparts.
2. **Additional-finding evaluation** — independently review a *sample* of other
   findings, retaining unresolved cases and reporting uncertainty.

Sampling makes this practical without reviewing every alert. NIST SATE used
sampled manual assessment of production-software warnings and explicitly retained
an "unknown" category (SATE V report, §3.1.2).

For buyer-facing precision, include ordinary repository snapshots and ordinary PRs
too. A collection deliberately selected for known vulnerabilities does not
represent everyday alert volume. Ordinary PRs still need sampled review; "not a
security-fix PR" does not establish that the code is safe.

You can automate collecting candidate commits and metadata. Accepting them as
ground truth needs stronger evidence. PrimeVul documents why labeling every
function changed by a security fix as vulnerable produces incorrect labels.

### 10.3 For the auto-engineering loop: stable evaluator, split development from holdout

Yes, the loop needs trusted ground truth. It needs *enough validated cases to
assess the changes* — not complete knowledge of every vulnerability in every
application.

A bounded improvement loop:

1. Evaluate the current tool on the development suite.
2. Produce a failure breakdown: missed known issues, confirmed false alarms, scan
   failures, duplicates, and cost.
3. Propose a tool change addressing a failure category.
4. Re-evaluate the candidate against the same cases and resource budget.
5. Accept it only when it meets predefined improvement *and regression*
   constraints.

For example, improving known-issue recall should not automatically justify
doubling false alarms or exceeding the CI time budget. Keep these measurements
separate instead of immediately collapsing them into one reward.

Three safeguards matter:

- The engineering agent can change the SAST tool, but **cannot** change the
  evaluator, expected answers, or evaluation inputs to improve its score.
- Development feedback can be detailed. Final holdout cases stay outside the
  optimization loop; repeatedly optimizing against their scores would turn them
  into development data.
- Related snapshots, copies, and fixes stay in the **same** split. Include
  held-out repositories and later cases to assess generalization.

For stochastic tools, compare repeated runs under the same policy. Determine
repetitions from pilot variability and the improvement you want to detect.

The execution and comparison can be highly automated. New ground-truth acceptance
and ambiguous-finding adjudication remain review tasks. Once a reviewed case is
accepted, its cost is amortized over many future tool versions.

### 10.4 A concrete improvement already available: separate execution unit from scoring unit

The 156 disclosed cases refer to only **103 distinct repository/commit
combinations**. Where scan roots and configurations match, scan a snapshot *once
per trial* and score all its known issues against that output. The current runner
(`scripts/run.py:220`) scans case by case.

That saves repeated work and prevents another known vulnerability in the same
snapshot from being treated as an unrelated false alarm.

One scope constraint remains: 128 of the 156 cases come from three repositories.
That supports a focused *agentic-application* benchmark much better than a
universal SAST-vendor ranking. Expanding application and framework diversity would
strengthen buyer relevance more than producing many synthetic variants.

**Recommendation:** prioritize trustworthy target-level scoring, validated real
fixed pairs, sampled alert review, and development/holdout separation. Those
foundations serve both purchasing comparisons and the engineering loop — without
requiring a factory of synthetic repositories.
