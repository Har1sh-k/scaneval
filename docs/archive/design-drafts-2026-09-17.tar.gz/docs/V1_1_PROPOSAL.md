# SASTbench v1.1 proposal

Accepted design amendments · Updated 2026-09-17 · Implementation pending.

Read alongside [V1_PROPOSAL.md](V1_PROPOSAL.md) and [EVALUATION_MATH.md](EVALUATION_MATH.md). This document records the accepted changes without duplicating the baseline proposal. It takes precedence over v1 on the decisions listed below.

## 1. Framework independence and backend selection — accepted

- Keep the corpus, scorer, and result format independent of Inspect and Harbor.
- Keep a direct execution/import path for SAST products: CLI/container adapters and SARIF/native-JSON imports.
- Compare Inspect and Harbor on a small representative integration before selecting an agent backend.

**Running 3–4 models alone does not justify adopting Inspect. Its value depends on how much orchestration and debugging work it actually removes from the project.** Apply the same criterion to Harbor. Either integration must use the common SASTbench result contract and scorer.

Inspect and Harbor remain candidates. The selection must account for the intended workload: comparing models under a common harness, evaluating complete agents, and supporting native SAST products.

## 2. Multi-model evaluation — accepted

Allow one configuration to declare several model/provider combinations. The planner expands compatible combinations of models, unique scan inputs, conditions, and repetitions. Execution grouping follows v1's input/root/language/configuration contract; shared targets do not trigger redundant scans.

- Hold the harness, prompts, tools, context policy, inputs, and budget policy fixed for model comparisons. Evaluate native product configurations under the separate product contract.
- Bind execution to the requested model and record provider, model ID, revision where available, parameters, and observed identity. Reject known mismatches; explicitly record identities that cannot be independently verified.
- Enforce provider-specific concurrency, rate limits, and declared spending limits; record actual usage where available.
- Keep operational retries distinct from independent repetitions. Preserve retry history and account for its cost.
- Store results per system and repetition; compare systems on common cases using the paired reporting defined in the math specification. Freshness comparisons use a common eligible slice.
- Mark incompatible model/tool combinations unsupported or place them in an explicitly different comparison profile.

Multi-model support is a SASTbench requirement regardless of the selected execution backend.

## 3. Backend comparison deliverable

Amend v1 deliverable **D3**: replace the Inspect-only integration spike with a small Inspect–Harbor comparison. Use a common selection of existing cases, the same SAST agent with at least two compatible models, and the direct execution path as a reference where applicable.

Evaluate:

- **Behavior preservation:** prompts, tools, generation settings, and budgets remain faithful to the selected comparison contract.
- **Result compatibility:** identical canonical findings, labels, and scorer versions produce identical scores through every path.
- **Operational handling:** timeouts, failures, retries, and resumed work retain correct status and accounting.
- **Observability:** record available transcripts, tool activity, usage, and timing; identify what each integration cannot observe.
- **Engineering value:** compare integration effort, orchestration/debugging work removed, and expected maintenance burden.

Deliver a short comparison and a backend decision with reasons. Retaining the direct runner is a valid outcome if neither framework provides enough benefit. The comparison does not commit the project to maintaining both integrations.

Relevant integration references: [Inspect evaluation sets](https://inspect.aisi.org.uk/eval-sets.html), [Inspect agent bridge and configuration](https://inspect.aisi.org.uk/agent-bridge.html#generation-config), [Harbor concepts](https://docs.harborframework.com/core-concepts), and [Harbor custom verifiers](https://docs.harborframework.com/core-concepts/jobs/custom-verifiers).

## 4. Real-world safe-capability annotation pilot — accepted

Prioritize human-reviewed safe-capability regions in ten real repositories. Keep deployment and authorization assumptions in those annotations. Evaluate useful context understanding through the existing capability-safe false-positive metric, without adding a separate “recognize educational repositories” score.

Annotate specific regions and security properties, with pinned commits, supporting guard/invariant evidence, and human review records under v1's validation requirements. Ten repositories is the pilot coverage target; each region must represent a meaningful analysis challenge. A safe-region annotation does not establish that the entire repository is safe.

Prioritize previously disclosed CVE fixes as a source of negative controls: they provide a documented vulnerability and a candidate repair. Pin the vulnerable/fixed snapshots, validate that the repair removes the specific root cause under the recorded assumptions, and map the target into the fixed code. An alert is an FP only when its claim is false; overlap with patched code alone is insufficient.

A validated fix supplies a fixed-target control. It also supplies a capability-safe control when the powerful operation remains present and is properly constrained. A patch that deletes the operation supplies only the fixed-target control. Other findings in the fixed snapshot follow v1's review policy.

## 5. False-positive safeguards and review — accepted

These safeguards use deterministic code and human-reviewed ground truth. An LLM judge is not required.

| Safeguard | How it works |
|---|---|
| Recall within a review budget | Code selects the first $B$ ranked claims and scores accepted matches. |
| Alert precision | Humans review sampled findings; code calculates estimates and uncertainty. |
| Safe/fixed controls | Humans validate the negative labels; code scores sufficiently clear matches. |
| Specific credit and deduplication | Structured matching handles clear cases; humans resolve ambiguous claims. |
| Promotion constraints and spam baselines | Deterministic rules and scripted test outputs. |

Freeze the review budget and ranking policy before evaluation; retain the full output for burden measurement and sampling. Count distinct allegations when applying the budget, including allegations bundled into one report object. Each known root cause earns detection credit once.

Use flag-everything, duplicate-spam, and always-silent outputs to check the promotion rules. A candidate must satisfy the declared precision, safe-control false-alarm, completion, and review-burden constraints alongside detection performance. Insufficient review evidence leaves the relevant constraint unresolved.

## 6. Field applicability in corpus admission — accepted

Use `not_applicable` for an individual annotation field whose concept does not fit the case, with a short justification. For example, a missing authorization check may require evidence about the caller, protected operation, and permission decision while an injection-style taint-source field does not apply.

- `not_applicable`: the field's concept does not apply; record why.
- `unknown`: the field applies, but review has not established its value.
- `not_reviewed`: assessment of the field is pending.

These states describe annotation fields, not whether a case belongs in the corpus. They cannot bypass required root-cause evidence, validation, or the `represents` justification. Record the relevant security mechanism even when taint-specific fields do not apply.

## 7. Configurable case sampling and execution order — accepted

Support all eligible cases, a fixed selection manifest, or a reproducible sample stratified by vulnerability class. The per-class count is configurable; five is an illustrative development budget, not a statistical sufficiency requirement.

Proposed configuration:

```yaml
selection:
  mode: stratified_sample  # all | fixed_manifest | stratified_sample
  split: development
  stratify_by: canonicalKind
  cases_per_class: 5
  seed: 42
  diversity_by: [repository, variant_family]
execution:
  shuffle_order: true
  order_seed: 43
```

- Select once per comparison and give every scanner/model the same selected cases and controls. Freeze the selection across repetitions and baseline/candidate comparisons.
- Sample validated canonical targets without replacement, spreading coverage across repositories and distinct mechanisms where available. Report shortfalls if a class cannot supply the requested count; do not manufacture independent cases from repeated variants.
- Attach applicable validated fixed/safe controls to selected inputs under Section 14's shared-snapshot policy; additional fixed-only scans are opt-in, not mandatory per target. Record unavailable controls, group shared inputs, and recognize all applicable known targets under v1's scoring rules. Report planned and actual target, repository, control, and scan counts.
- Save the release version, selection settings and seed, exact case IDs, input hashes, scoring weights, and execution manifest. Treat the manifest as the reproducible selection record.
- Configure execution-order shuffling separately from case sampling. Record the actual order and keep fresh trial state. These seeds control selection/order; model sampling settings remain separate.

Use a small fixed set for quick regression checks, rotating development samples for broader coverage, and a frozen shared evaluation set for release/buyer comparisons. Rotating a development sample does not make previously used cases eligible for protected evaluation. Report sample coverage and uncertainty; random selection does not remove memorization or supply missing corpus diversity.

## 8. Memorization and identity-dependence audit — accepted

Keep this audit alongside the main buyer-facing detection score. Prior knowledge can legitimately help a product detect known vulnerabilities. The audit tests available advisory knowledge and sensitivity to code/identity changes; it cannot prove whether an individual finding came from memory or analysis.

| Check | Method | Interpretation and limit |
|---|---|---|
| Identity-only probe | In a separate fresh session, provide repository and version, without code, vulnerability description, or candidate CVE. Allow `UNKNOWN`; verify the advisory/version association. | A correct answer shows advisory knowledge is available without inspecting code, not that the scored scan used it. A negative response does not establish absence from training. |
| Vulnerable–fixed pair | Compare independent scan observations of validated vulnerable/fixed states, reusing eligible planned scans under Section 14. Check whether the same root-cause allegation disappears. | Measures discrimination between vulnerable and repaired code. Flagging both may reflect recall, coarse rules, or poor analysis; successful discrimination can also use prior patch knowledge. Later snapshots do not isolate the patch's effect. |
| Identity sensitivity | On a small research subset, repeat both scans with pseudonymous project identity, preserving behavior and useful domain context. | A performance change suggests identity dependence, but transformations can also affect analysis. Neither a drop nor unchanged performance isolates memorization. |

Start with validated fixed pairs and inexpensive identity probes where supported. Mark unavailable probes explicitly; querying a product's presumed base model is not equivalent to probing the product. Reserve deidentification for the research subset. Repeat paired comparisons for nondeterministic systems under the same budgets and configuration, following the existing pilot/uncertainty policy.

Use fresh trial state, remove original Git history, benchmark labels and advisory hints, and record model/ruleset versions. Snapshot scans omit `.git`; native PR runs may use minimal synthetic base/head history from the approved snapshots, with neutral commit messages and no original history. Disable external retrieval in the controlled track; keep native connected products in their declared comparison profile. Never pass probe answers into scored sessions. Workspace isolation cannot rule out hidden provider-side retrieval or later training exposure.

Use the earliest known public answer-bearing artifact and the bound model's documented cutoff as supporting provenance, not a memory detector. The CVE publication date alone is insufficient. Temporal performance signals can change with benchmark construction: [Test of Time](https://aclanthology.org/2026.acl-long.1693/).

Report advisory recall, vulnerable–fixed discrimination, identity sensitivity, and retrieval/provenance limitations separately, including unavailable or inconclusive results. Do not report a single “memorization percentage” or a binary memory-versus-reasoning verdict. The optional contrast formulas remain in [EVALUATION_MATH.md](EVALUATION_MATH.md#7-contamination-and-grounding-research-only).

Do not embed “if you know CVE-X, print it” instructions in source: they prime the answer. Random case selection is not a memorization control.

## 9. Long-term evaluation protocol and invocation — accepted

Build a framework-independent evaluation protocol and replayable engine. SDKs and adapters implement its boundaries; no particular harness or orchestration backend defines the meaning of a finding or score. Integrate the owner's own harness first. Keep the Inspect–Harbor comparison in Section 3 open.

Define four versioned contracts:

| Contract | Contents and boundary |
|---|---|
| Scan request | Input snapshot/scope; base/head refs and diff access for PR mode; model and system configuration, limits, opaque run ID. No expected findings or advisory labels. |
| Scan result | Execution status, ranked security claims, locations, evidence, usage where available, and native-output references. |
| Trace event | Typed observations of model calls, tools, context changes, handoffs, and finding processing. Optional, with declared capture capabilities. |
| Evaluation record | Target matches, review decisions, metrics, and their provenance. Evaluator-only; never supplied to the harness. |

Keep schemas language-neutral, with explicit compatibility rules and versioned migrations. Reuse [JSON Schema](https://json-schema.org/understanding-json-schema/reference/object) for structural validation, [OpenTelemetry](https://opentelemetry.io/docs/concepts/signals/traces/) for trace relationships, and [SARIF](https://docs.oasis-open.org/sarif/sarif/v2.1.0/os/sarif-v2.1.0-os.html) for static-analysis result interchange. These standards do not establish security correctness.

Borrow Inspect's configuration, CLI/Python invocation, interchangeable execution components, and inspectable-run experience; do not require users to adopt its agent loop. [Inspect task interfaces](https://inspect.aisi.org.uk/tasks.html).

Proposed interfaces below are illustrative, not implemented. Python notation does not require the evaluated harness to be Python:

```python
def scan(request, observer=None) -> ScanResult:
    ...  # thin adapter around the existing harness
```

```yaml
harness: my_harness.benchmark:scan
selection_manifest: pilot.yaml
models: [model_a, model_b]  # aliases resolving to pinned configurations
repetitions: 3             # illustrative pilot, not a fixed requirement
trace: content
```

```bash
sastbench run bench.yaml
sastbench report runs/<run-id>
```

The same engine should expose `sastbench.evaluate("bench.yaml")`. Invocation resolves the frozen workload/configuration, prepares isolated trials, launches a worker through the adapter, collects results, then scores and reports outside the worker. Preserve the existing budget, shared-input grouping, and retry/repetition policies. Library invocation must retain the worker/evaluator boundary; an object field alone does not protect labels.

## 10. Adapter architecture and heterogeneous outputs — accepted

Separate three integration roles; one integration package may implement all three:

| Role | Responsibility |
|---|---|
| Execution adapter | Invoke an existing function, CLI/container, or service with the sanitized request; return findings, status, and provenance. Preserve the declared native workflow. |
| Result importer | Translate native JSON, SARIF, or a documented report format into canonical claims. Retain the source artifact and extraction references. |
| Tracing connector | Use framework callbacks, existing telemetry, or wrappers to emit common events. Optional; unavailable internals do not prevent output-based evaluation. |

For the owner's harness, prefer a small structured exporter over parsing its human-readable report. Canonical claims preserve finding ID, original security allegation/message, primary and related locations, native rule/CWE/type/severity, rank or original order, evidence references, and raw-output references. Keep execution state and trace availability in the run record.

- Centralize versioned kind/rule mappings in the engine. Adapters translate representations; they neither receive ground truth nor decide TP/FP status.
- Preserve missing and unmapped information. Never invent precise locations, discard unsupported claims silently, or count parser failure as a successful empty scan.
- Retain distinct allegations and duplicate provenance so normalization cannot bypass Section 5's review budget or inflate detection credit.
- Free-text extraction needs a documented parser and review of ambiguous claims. An LLM translator is not required; schema-valid extraction alone does not establish semantic correctness.
- Preserve native outputs under the capture policy so adapter fixes can be evaluated without rerunning the scanner. Version adapter changes and retain earlier normalized results.

## 11. Optional instrumentation SDK and model visibility — accepted

Use a small observer API, not a mandatory replacement framework. Instrument shared model-client and tool-dispatch boundaries, with optional markers for context selection and finding filtering. Prefer existing callbacks; custom stages may use a span/context manager. Normal scans must work without the SDK.

Support `off`, `metadata`, and `content` tracing. Trace mode controls diagnostic recording, not mandatory run provenance or finding submission. For the owner's debug runs, relevant prompts, responses, exposed reasoning, tool results, and context changes may be retained locally. Redact credentials, record capture omissions, and require separate permission for uploading artifacts. Redaction affects stored records, not the request sent to the model.

The event contract should support:

- Model request/response, tool call/result, context inclusion/truncation/summary, agent handoff, candidate/filter/submitted finding, and run completion/error events.
- Schema version, event/run/producer IDs, per-producer sequence, call/attempt IDs, parent/link relationships, timestamps/durations, and content-hash references where applicable. Parallel activity has a partial order; wall-clock timestamps alone do not establish causality.
- Requests captured after context selection/truncation at the model-client boundary, with links to included tool results or derived summaries. A file accessed by a tool is not automatically model input; recorded input is not proof of use.
- Explicit capture capabilities and complete/partial/redacted/unavailable status. Distinguish observer-recorded facts, harness self-reports, and model statements. Hashes detect artifact changes, not whether a producer reported truthfully.

Keep instrumentation passive: preserve prompts, generation settings, streaming, tool results, retries, and exceptions; measure overhead. Recording failures must be visible as trace gaps, not silently alter the scan or its score. Filesystem/network restrictions remain externally enforced, not implemented by tracing hooks.

Retain only reasoning text or summaries actually exposed by the runtime; mark unavailable otherwise. Do not add elicitation prompts or enable a different reasoning mode merely to debug a scored run. Explanations are not guaranteed to faithfully reflect what influenced an answer: [Turpin et al., NeurIPS 2023](https://arxiv.org/abs/2305.04388).

For Section 8's recall audit, record where a verified CVE/GHSA association first appears in the captured causal history: input, tool result, or model output. “No prior recorded source” is an observation, not proof of memorization. Only submitted findings earn detection credit; discarded hypotheses remain debugging evidence.

## 12. Deterministic reading, replay, and acceptance checks — accepted

Determinism means the same saved evidence, labels, review decisions, and evaluation rules produce the same canonical records and metric values. It does not promise identical agent reruns or deterministic interpretation of internal reasoning.

Distinguish three levels:

1. **Structural validation:** field types, schema versions, references, locations, and event relationships. Deterministic validators/parsers handle these.
2. **Recorded-fact analysis:** calls, failures, recorded model inputs, identifier mentions, and candidate-to-report changes. Deterministic queries handle these only to the extent capture supports them; missing evidence remains unknown.
3. **Security interpretation:** whether a claim establishes the target root cause, or an explanation indicates recall. Use accepted matching rules for clear cases, human review for ambiguous claims, and the separate experimental audit for recall. Structured data alone does not settle these questions.

The replay contract is conceptually:

```text
canonical = normalize(raw_output, adapter_version, mapping_version)
metrics = evaluate(canonical, run_record, optional_trace, label_snapshot,
                   review_snapshot, scoring_policy, evaluator_version,
                   analysis_settings)
```

Freeze the referenced inputs and versions, including execution status, usage, weights, and statistical seeds. Replay must not call a model or depend on live web data. Store the run manifest, native artifacts, canonical results, optional trace, and evaluator-side decisions with hashes and capture metadata. Label corrections, reviews, or adapter changes produce a new evaluation record; retain the prior one. Metric changes must be attributable to declared input/version changes.

Ship conformance fixtures verifying equivalent native formats normalize consistently; duplicates/bundled claims cannot inflate credit; parse failures differ from empty success; missing locations remain missing; trace gaps prevent unsupported conclusions; and frozen inputs reproduce metric values. Check recording on/off parity with deterministic or stubbed clients, including streaming/async behavior, and measure instrumentation overhead separately.

Extend the existing deliverables:

- **D1/D3:** protocol schemas, CLI/library interfaces, the owner's harness adapter, optional observer helpers, and adapter conformance tests. Retain the native-product path and backend comparison.
- **D4:** versioned, replayable run bundles with declared trace completeness and capture policy.
- **D5/D7:** a local trace timeline, baseline/candidate comparisons on the same workload, and integration/replay examples. Respect protected-evaluation feedback limits.

For this integration work, build contracts and fixtures first, the owner's harness integration second, then tracing/reporting and additional adapters. The long-term result serves purchasing comparisons, harness debugging, regression gates, and controlled research through the same evidence contracts; no hosted observability service is required.

## 13. Organization-owned corpora and private evaluation — accepted

Let an organization bring its own repositories and findings as a versioned corpus pack, without forking SASTbench. Use the same execution adapters, result contracts, review workflow, and replayable evaluator. Support public packs, private packs, or an explicitly selected combination; give each pack a namespace, version, and frozen manifest.

### Easy case intake

Provide a starter template and importers for local JSON/SARIF findings, with configurable field mappings for ticket/CSV exports. Internal security reviews, incidents, previous scanner reports, and public advisories can supply candidates. A CVE or public disclosure is not required.

Illustrative commands, not implemented:

```bash
sastbench corpus init ./private-corpus
sastbench corpus import findings.json --into ./private-corpus
sastbench corpus validate ./private-corpus
```

Imports create draft cases. Validation checks structure, references, and admission requirements; it does not turn a scanner allegation into confirmed ground truth. Human acceptance must establish the security claim, affected snapshot/root, relevant locations, deployment/authorization assumptions, supporting evidence, and what the case represents. Record the reviewer and validation tier. A closed ticket, suppression, or accepted risk is not automatically a false positive or safe control.

Reuse the existing canonical-target/variant-family rules. Fixed counterparts and safe controls are optional inputs but must be validated before contributing negative-control scores; missing controls remain visible. Allow namespaced organization-specific categories and policy metadata, with declared matching rules, rather than forcing unrelated cases into an existing kind.

### Select and tune against the private pack

Example configuration, extending Section 9:

```yaml
corpora:
  - id: org-private
    manifest: ./private-corpus/manifest.yaml
selection_manifest: ./private-corpus/splits/development.yaml
harness: my_harness.benchmark:scan
```

Resolve repository references into pinned inputs using the common materializer; credentials remain outside manifests and artifacts. Ordinary architecture/security-policy context may be supplied to the harness as a versioned runtime input. Finding reports, fix descriptions, and expected answers remain evaluator-side during scored scans.

- Tune prompts, rules, context selection, and orchestration on the development split. Compare baseline and candidate on the same frozen workload and policies; this option does not automatically change or fine-tune a model.
- Keep related targets, fixes, variants, and overlapping snapshot families together across splits. Use genuinely later changes for within-repository evaluation or held-out repositories for cross-project claims. Disclose the split's limitations; repeatedly used tuning cases are not protected evaluation.
- Freeze the scorer, labels, and acceptance constraints before candidate comparisons. Human-reviewed development failures may inform tuning; holdout answers and per-case debug feedback must not leak into that loop.
- Report public and organization-specific results separately. Any combined score needs explicit weights and component results; a custom-corpus score is not comparable to the public benchmark by default. Existing precision, safe-control, completion, and review-budget safeguards still apply.

### Privacy and deliverable

Keep private source, labels, reports, and traces in organization-controlled storage by default, with no automatic publication or telemetry upload. Local artifact storage does not make remote inference private: require an organization-approved model/data-egress policy, including retention, before sending code to a provider. Private status is not proof of no prior model exposure; retain the provenance limits in Section 8.

Extend **D2/D7** with a private-corpus starter pack, import field-mapping examples, actionable admission diagnostics, and a worked development/holdout evaluation using the same CLI/library interfaces. Preserve draft/reviewed/released states and pack versions so adding a case never silently changes an earlier experiment's denominator.

- [ ] **Documentation follow-up:** Create `docs/BRING_YOUR_OWN_CORPUS.md` once the interfaces are implemented. Include step-by-step setup, repository/finding import and field mapping, human validation, development/holdout splits, privacy/model-provider settings, and running/reading results, with one complete worked example.

## 14. Shared snapshots and rolling fixed controls — accepted

Combine execution where one real snapshot covers multiple targets; keep their root-cause labels separate. Version-range overlap identifies candidate inputs, not confirmed vulnerability states:

- CVE1 affects **1.0–1.7**, CVE2 affects **1.4–2.8**: a validated **1.7 snapshot** can test both in one scan.
- CVE1 affects **1.0–1.7**, CVE2 affects **2.0–2.8**: no shared affected version exists, so their positive tests need separate snapshots. The planned **2.8 scan** can also test CVE1 as a negative control if its repair is validated there.

Upper bounds alone are insufficient: establish introduction/fix boundaries, branch/configuration assumptions, and actual code state. Pin the exact commit/tree and validate target locations and semantics on it before evaluation. Reuse output only under the same execution identity: input, root/language scope, system/model configuration, environment, condition, budget/tool contract, and repetition. Preserve the existing split protections.

### Reuse later planned scans

After validating each target's state, the sequence can be:

| Planned snapshot | CVE1 | CVE2 | CVE3 |
|---|---|---|---|
| A | Vulnerable | — | — |
| B | Fixed control | Vulnerable | — |
| C | Fixed control | Fixed control | Vulnerable |

Each row requires one scan per system/configuration/repetition. The evaluator checks all applicable targets and controls against that output. “—” means not assessed.

Prefer an already-planned later scan as the fixed-state observation for an earlier target. Do not automatically schedule a dedicated fixed-only scan for every CVE. Additional controlled pairs remain available for explicitly selected experiments. Validate every fixed cell: a repair in B does not establish that the issue remains fixed in C.

### Scoring and coverage

- Score all applicable known targets and validated controls within the declared scan scope. For two distinct positive targets, finding both gives 2/2 and finding only one gives 1/2; CVE aliases for one root cause do not create extra detection credit.
- Charge execution cost once. Multiple target outcomes from one scan are not independent runs; never reuse that output as an additional repetition.
- A fixed control concerns the specific repaired root cause, not the entire repository. An unrelated genuine finding nearby is not an FP. The capability-safe distinction in Section 4 still applies.
- If the last CVE—or any target—has no eligible fixed-state observation, retain its detection result and mark fixed-control coverage/pair correctness unavailable. Missing observations, failed executions, and out-of-scope code must not count as passed negative controls.
- Freeze control selection and aggregation before comparing tools. Repeated appearances of an old fixed CVE must not dominate the score or count as independent vulnerabilities; report target-level control coverage and account for shared snapshots/families.
- Later releases contain unrelated changes. Rolling controls support practical detection/false-alarm evaluation, not an isolated patch-effect experiment or proof of memorization. Keep those claims separate from tightly matched research pairs.

### Native PR-mode evaluation — accepted

Invoke the harness's native PR mode once per change set, system/configuration, and repetition. Supply base/head references and repository context; provide the diff or let the harness derive it. This evaluates diff-led review, not a full-head scan or subtraction of two full scans. Multiple internal model calls remain part of one invocation.

Preserve and record native scope differences observed in the local implementations:

- **DeepSec:** the diff selects changed files; analysis reviews their contents, not only added lines.
- **sv-agent (`securevibes-agent`):** starts from the merge-base/head diff and can expand its focused analysis to related unchanged files.

Declare scoring scope before execution: changed-file review or change-affected flows, with repository context available where supported. Access to the full repository does not make every vulnerability a PR target. A validated fixed control can qualify within a reviewed changed file even when the repair lines are unchanged, provided the declared scope covers that repaired behavior; relevant cross-file controls may also qualify. Unrelated fixed targets remain unassessed. Traces describe actual coverage but must not remove missed, in-scope targets from the denominator.

Record required bootstrap/indexing separately as setup, including its time, cost, and state provenance; include setup in total cost reporting and distinguish fresh from prepared-state runs. Reuse only declared, compatible state generated without evaluator labels. Do not mandate a fresh baseline scan for every PR or a fixed-only scan for every target. Synthesized dual-scan review remains an explicitly selected, separately reported workflow, not a silent fallback.

**Adapter follow-up:** the current [sv-agent adapter](../adapters/securevibes-agent/adapter.py) runs base bootstrap, then native `pr`, then selects findings with new IDs. Make that setup explicit rather than unconditional per PR, and preserve native PR findings separately from baseline state. The [PR runner](../scripts/pr_runner.py) must also make its existing dual-scan fallback opt-in and report it distinctly. These changes are pending; this amendment changes the evaluation contract, not the implementations.

## 15. Optional Jev corpus-quality audit — experiment

Test Jev as a data-quality assistant for CVE annotations during corpus preparation, not as a ground-truth judge. This is optional and must not block v1.1; scanning, scoring, and replay remain independent of Jev.

Supply the advisory, relevant patch/code, and current annotations—not just a CVE ID. Ask bounded questions:

- Does the advisory support the assigned vulnerability category?
- Does the supplied patch appear to address the annotated mechanism?
- Is essential supporting evidence missing from the annotation?
- Do two case descriptions potentially represent the same root cause?

Use declared answer options and existing evidence IDs, with `unknown` or `insufficient_context` where appropriate. Outputs are review suggestions, not proof. A shared CWE or similar description alone cannot establish duplication.

**Cleanup workflow:** deterministic validation first; Jev proposes review items; a human approves corrections; code applies and versions the accepted changes before the corpus release is frozen. Keep schema/path checks, exact identifier matching, date/version comparisons, and score calculations in code. No automatic deletion, merging, overwriting of validated labels, or declaration that a fix is safe. Preserve original records and reviewer decisions; follow Section 13's data-egress policy for private inputs.

**Pilot and adoption bar:** compare with the existing review workflow on a varied human-reviewed sample containing correct records, known annotation errors, and possible duplicate families. Review some unflagged records too. Measure confirmed errors found, incorrect correction suggestions, missed known errors, reviewer time, and API cost. Retain the option only if it improves error discovery or saves review effort without degrading annotation quality; inconclusive results do not justify making it a dependency.

**Deliverable:** a review queue and short adopt/skip report, retaining input/evidence hashes, question definitions, resolved model version, raw judgments, and human outcomes. No Jev calls during score replay. Using Jev inside an evaluated harness remains a separate experiment, not part of this corpus audit.

Implementation references: [TypeSafe's bounded question interface](https://docs.typesafe.ai/primitives), [documented model limitations](https://docs.typesafe.ai/model-jaggedness/jev-1.13), and [commit-miner's classification/evidence design](https://github.com/devanshbatham/commit-miner/blob/main/docs/JEV_PROTOCOL.md). These motivate the experiment; they do not establish CVE-annotation accuracy.
