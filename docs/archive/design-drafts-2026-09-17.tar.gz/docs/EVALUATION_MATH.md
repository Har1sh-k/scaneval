# SASTbench evaluation math

Companion to [V1_PROPOSAL.md](V1_PROPOSAL.md) · Draft, 2026-09-06.

Sections 1–4 define the proposed v1 measurements. Sections 5–7 retain optional diagnostics and research contrasts. These are specifications, not implemented metrics. Definitions adapted to whole-repository SAST are distinguished from cited precedents. A zero denominator is **N/A**, unless an explicit convention below says otherwise.

## 1. Target detection and paired comparisons

Let $i$ index $N$ accepted canonical targets, $s$ a system configuration, and $r$ one of $k_i$ assigned repetitions. Let $Y_{sir}=1$ only when an accepted target hit is delivered within budget; otherwise it is zero. Deduplicate root-cause matches before scoring. Valid hits in partial outputs may count, but a partial run cannot establish that a control was checked and found safe. Record completion separately.

$$
\widehat p_{si}=\frac{1}{k_i}\sum_{r=1}^{k_i}Y_{sir},
\qquad
\widehat D_s=\sum_{i=1}^{N}w_i\widehat p_{si},
\qquad w_i\geq0,\quad\sum_iw_i=1.
$$

Freeze weights and the common comparison set before seeing results. Equal-target weighting uses $w_i=1/N$. For a separately reported equal-project or equal-family view with $G$ **disjoint** groups and $n_g$ targets per group:

$$
w_i=\frac{1}{G\,n_{g(i)}}.
$$

Group variants before applying these weights; do not let extra CVE IDs create extra credit. One scan can supply several target outcomes without becoming several independent executions.

For two systems evaluated on the same targets:

$$
\widehat\Delta_{A,B}=\sum_iw_i(\widehat p_{Ai}-\widehat p_{Bi}).
$$

Use the same paired structure for uncertainty. No expression here is whole-repository precision: the complete set of real vulnerabilities is unknown.

## 2. Fixed pairs and safe controls

For an eligible validated pair, $a^V,a^F$ indicate completed valid scans; $y^V$ is target detection; $z^F$ is an incorrect allegation of **that same root cause** in fixed code. With nonnegative weights $v_i$ summing to one over assigned eligible pairs:

$$
\widehat Q_s=
\sum_{i\in\mathcal P}\frac{v_i}{k_i}
\sum_r a^V_{sir}a^F_{sir}y^V_{sir}(1-z^F_{sir}).
$$

Match repetitions by a predeclared schedule, not the best vulnerable run and quietest fixed run. Failed/incomplete pairs earn no pair credit. Among completed pairs, show correct, both-flagged, both-silent, and reversed outcomes. This adapts [PrimeVul's paired-function evaluation](https://arxiv.org/abs/2403.18624) to target-level repository reports; it does not certify the entire fixed repository as safe.

For a control set $\mathcal C$, let $z=1$ denote a false allegation and $a=1$ a completed valid scan. With fixed nonnegative control weights $u_j$ summing to one:

$$
\widehat F_{\mathcal C,s}=
\frac{\sum_{j\in\mathcal C}\frac{u_j}{k_j}\sum_r a_{sjr}z_{sjr}}
     {\sum_{j\in\mathcal C}\frac{u_j}{k_j}\sum_r a_{sjr}}.
$$

Apply this **separately** to capability-safe controls and fixed-target controls. Always show assigned/completed coverage beside it: a scanner that fails all controls has no measured FP rate, not 0%. For mixed-intent inputs, credit requires a completed scan, a target hit, and no allegation on any required safe control.

## 3. Reviewed precision, unresolved claims, and burden

Review normalized unique claims under frozen deduplication rules. Keep raw duplicates in burden counts. For sampled claim $a$, record inclusion probability $\pi_a>0$ and adjudicated class $\ell_a\in\{T,F,U\}$: true, false, or unresolved. Within a declared review population, estimate class totals by:

$$
\widehat N_\ell=\sum_{a\in S}\frac{\mathbf1[\ell_a=\ell]}{\pi_a}.
$$

Write $T,F,U$ for these estimated totals. Equal-probability sampling cancels the common weight; oversampling suspicious outputs does not. Report:

$$
\widehat P_{\mathrm{resolved}}=\frac{T}{T+F},
\qquad
\widehat U=\frac{U}{T+F+U},
\qquad
P_{\mathrm{sensitivity}}\in
\left[\frac{T}{T+F+U},\frac{T+U}{T+F+U}\right].
$$

The interval assigns unresolved claims entirely false or entirely true. It is **not a confidence interval**; sampling uncertainty and adjudication error remain. Weighted totals have a design-based interpretation, while their ratios need not be exactly unbiased. No estimate extends to claim strata with zero sampling probability. Out-of-scope items need an explicit policy, not silent removal.

For review burden, if stratum $h$ contains $M_h$ delivered alerts and measured mean triage time $\widehat t_h$:

$$
\widehat L=\sum_h M_h\widehat t_h.
$$

This includes true, false, unknown, and duplicate-alert handling. Do not substitute “unknown count × sampled FP rate” for review time. These formulas specify this proposal's sampling policy; [NIST SATE](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.500-326.pdf) supplies the production-warning review precedent, not a turnkey estimator for this corpus.

## 4. How many cases and repetitions?

For **independently sampled cases**, equal weights, and $k$ conditionally independent Bernoulli runs per case, with true success probability $p_i$:

$$
\operatorname{Var}(\widehat D)=
\frac{\operatorname{Var}(p_i)}{N}
+\frac{\mathbb E[p_i(1-p_i)]}{Nk}.
$$

For the fixed corpus, conditional run noise alone is:

$$
\operatorname{Var}(\widehat D\mid p_1,\ldots,p_N)
=\frac{1}{N^2k}\sum_i p_i(1-p_i).
$$

More repetitions reduce run noise, not corpus-selection uncertainty. A rough paired, independent-case planning approximation is:

$$
N\approx
\frac{(z_{1-\alpha/2}+z_{1-\beta})^2\sigma_d^2}{\delta^2}.
$$

Here $d_i=\widehat p_{Ai}-\widehat p_{Bi}$ at the planned repetition count, $\sigma_d^2=\operatorname{Var}(d_i)$, $z_q$ is a standard-normal quantile, $\delta$ the minimum worthwhile difference, $\alpha$ the hypothesis test's Type I error rate, and $1-\beta$ power. These are specializations of [Miller's variance, pairing, and power analysis](https://arxiv.org/abs/2411.00640), not a universal $k$ recommendation.

**Actual protocol:** pilot; simulate candidate budgets using paired, clustered outcomes. Resample whole dependency groups, preserving systems, shared scans, variants, and repeats. Independent-case formulas do not fit correlated repository targets directly. With few repositories, show per-project and leave-one-project-out sensitivity; bootstrap intervals do not create representativeness. Predeclare interval-width/effect-size goals and stopping rules.

## 5. Reliability across repeated runs — optional

For $n$ independent trials of an unchanged system on one target, with $c$ successes and $1\leq k\leq n$:

$$
\widehat{\mathrm{pass@}k}
=1-\frac{\binom{n-c}{k}}{\binom nk},
\qquad
\widehat{\mathrm{all@}k}
=\frac{\binom ck}{\binom nk}.
$$

Use $\binom ak=0$ when $a<k$. These estimate “at least one success” and “all runs succeed,” then average across targets with frozen weights. The first follows [Chen et al.](https://arxiv.org/abs/2107.03374); the second is [τ-bench's pass^k](https://arxiv.org/abs/2406.12045).

They assume independent, identically distributed trials within a target: no feedback-driven retries, shared evolving memory, or cherry-picking. Report $n$ and $k$. Neither replaces mean per-run detection, nor guarantees that a buyer can identify the successful answer among conflicting reports.

## 6. Harmless-edit stability — follow-on diagnostic

Let $A$ and $A'$ be sets of normalized alert identities before/after a validated harmless edit, with paths/symbols remapped. Define:

$$
\mathrm{churn}(A,A')=1-\frac{|A\cap A'|}{|A\cup A'|}.
$$

When both sets are empty, define churn as zero **only for completed valid scans**. This is Jaccard distance applied to alerts, not a correctness score. Always pair it with vulnerable/fixed correctness: consistently wrong output can have zero churn. For stochastic tools, also measure unchanged-input repeat churn; edited-versus-original disagreement alone does not isolate the edit's effect.

## 7. Contamination and grounding (research only)

### Identity and temporal contrasts

For identity condition $\ell\in\{O,P,D\}$—original, pseudonymous with domain context preserved, strongly deidentified—define vulnerable/fixed discrimination on matched validated pairs:

$$
S_\ell=P(\text{target hit}\mid V,\ell)
-P(\text{same target alleged}\mid F,\ell),
\qquad I=S_O-S_P,
\qquad R=I_{\mathrm{pre}}-I_{\mathrm{post}}.
$$

Use the same pair set and weights, and a predeclared completion/missing-data analysis; never treat a failed fixed scan as reassuring silence. $I$ is an observed identity advantage; $R$ is the temporal triple difference discussed earlier. Neither is a probability of recall. Interpreting $R$ causally requires comparable cases, stable context/transformation effects, and genuinely unexposed post-cutoff cases. [Test of Time](https://aclanthology.org/2026.acl-long.1693/) shows why temporal performance signals can depend on benchmark construction.

For gating, let $H_i=\min_{a\in\mathcal A_i}t_a^{\mathrm{public}}$ over credible known answer-bearing artifacts, and $C_s$ the bound model's documented cutoff. Compare $H_i>C_s$ only when both are credible; otherwise mark unknown. This is an eligibility rule, not proof that no earlier artifact or later training exposure exists.

### Exposure regression

A possible descriptive model, fitted separately for each system, is:

$$
\operatorname{logit}P(Y_{ir}=1)=
\alpha_{g(i)}+\beta_E E_i+\beta_T T_i
+\beta_{ET}E_iT_i+\gamma^\top X_i.
$$

$g(i)$ is repository, $E_i=\log(1+\mathrm{frequency}_i)$ is a documented item-exposure proxy, $T_i$ indicates post-cutoff, and $X_i$ contains predeclared case covariates. The interaction tests whether the exposure association differs by period. Comparing “significant pre” with “not significant post” is not that test.

This is **Roberts-inspired**, not an exact replication: [Roberts et al.](https://proceedings.iclr.cc/paper_files/paper/2024/file/2d04d97593c8c33d415337f408ed0e1b-Paper-Conference.pdf) measured evaluated-item presence, not repository stars. Repository-constant stars are absorbed by repository fixed effects; sparse pre/post overlap or collinear covariates can make coefficients unidentifiable. Preserve clustering and report sensitivity; current frequency is not historical training exposure. Keep this outside v1 release gates.

### Grounding measurements

On cases with accepted structured evidence annotations:

$$
\mathrm{evidence\ coverage}
=\frac{\text{unique required evidence nodes supported by the report}}
       {\text{required evidence nodes}},
\qquad
\mathrm{citation\ precision}
=\frac{\text{checked citations supporting their associated claims}}
       {\text{checked citations}}.
$$

Sampling citations requires the review-weighting rules above. Complete-chain credit additionally requires every required connection to be supported. Matching IDs/locations checks annotation coverage, not the truth of arbitrary prose; support must come from validated structured rules or review. Missing annotations mean N/A. Traces establish observable access, not use, necessity, or internal reasoning; these scores remain separate from target detection.
