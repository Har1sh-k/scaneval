# SASTbench v1 proposal

Draft for review · 2026-09-06 · No implementation decisions approved by this document.

**Build a real-application SAST evaluation that helps buyers compare products and builders measure improvements.** Keep capability-safe false alarms central. Keep contamination controls; defer expensive memory-attribution experiments.

This consolidates the distinct ideas from [DESIGN_DECISIONS.md](DESIGN_DECISIONS.md), this conversation, the supplied Claude transcript, and the five Claude memory notes. Latest user direction takes precedence over older notes marked “agreed” or “final.” The original notes remain unchanged.

Read this document for scope and build decisions. [Evaluation math](EVALUATION_MATH.md) specifies the formulas, assumptions, and research-only contrasts. Section 8 compares packaging options and lists concrete deliverables.

## 1. Scope and comparison contract

- **First release:** agentic-application SAST, with the existing six vulnerability kinds. Keep generic applications and synthetic diagnostics separately reported. Broader industry coverage requires more application/framework diversity.
- **Product comparison:** evaluate the complete product configuration: edition, engine, rules, model, orchestration, context selection, and reporting. Allow native workflows under a common workload and declared budget policy.
- **Model comparison:** hold the harness, prompt, tools, context policy, and budgets fixed. Changing these evaluates a different system, not just a different model.
- **Workflows:** full-repository detection and separately scored PR review. Give scanners ordinary task inputs, never the selected CVE, expected locations, or “a vulnerability exists here” hints.
- **Network profiles:** a controlled, no-retrieval profile and, where necessary, a separately labeled native-service profile. A SaaS product whose internals are unobservable must not be described as hermetic.

Use a scorecard with explicit workload filters and constraints. Avoid a universal vendor ranking or an opaque composite score. OWASP mappings remain reporting metadata, not evidence that an entire category is covered.

## 2. Verified starting point

Counts below describe checked-in metadata, not independently validated vulnerabilities.

| Corpus | Cases | Repositories | Repo/commit snapshots | Snapshot/root/language groups |
|---|---:|---:|---:|---:|
| Disclosed agentic | 156 | 10 | 103 | 104 |
| All real-world | 189 | 16 | 128 | 129 |

- 23 disclosed snapshots are shared; the largest carries 12 cases. One snapshot has the same root but different language scopes.
- OpenClaw, n8n, and Flowise supply 128/156 disclosed cases. These are not 156 independent application samples.
- 49/189 real-world cases have PR metadata. This does not establish that their base/head boundaries are semantically correct.
- **Zero real-world capability-safe regions are annotated.** The six safe regions are in six Core cases. Publish their current result as diagnostic, not production false-alarm evidence.
- Only two disclosed cases require multiple regions; only one has annotations spanning multiple files. Existing annotations cannot support a general cross-file-grounding claim.

Current engine defects to address:

1. [run.py](../scripts/run.py) scans per case; [scoring.py](../scripts/scoring.py) labels unmatched findings false positive. A finding on another known issue in the same snapshot can be misclassified. It is not established that a scanner actually reports all eleven other issues.
2. Recall mixes finding-count TPs with region-count FNs; duplicate reports can inflate it. Whole-file location fallbacks can also receive overly generous matches.
3. Full scans use live clones; [pr_runner.py](../scripts/pr_runner.py) passes the full ground-truth case to native adapters. This is a contract exposure, not proof that an adapter consumed it.
4. [cutoff.py](../scripts/cutoff.py) admits missing dates; the runner filters before execution. `--model` selects a cutoff profile without binding inference. [Semgrep's adapter](../adapters/semgrep/adapter.py) uses live `--config auto`.
5. Versions, commands, stdout/stderr artifacts, and skip reasons already exist. Preserve them; add missing repeat, usage, environment, and policy provenance. Some adapter guidance still conflates errors with empty successful scans.

## 3. Corpus admission: every case needs a purpose

Retain the corpus and ingestion tools. Review and regroup cases before expanding it; do not assume all existing labels or fixes are verified.

Each accepted case needs:

- `represents`: the analysis challenge it tests, or the independent replication it contributes.
- A reviewable coverage signature: language/framework idiom, source/trust boundary, sink or security operation, guard-failure mechanism, and interprocedural span. Use `not_applicable` where taint terminology does not fit.
- A canonical target/root cause, related-variant family, affected snapshots, ordinary deployment assumptions, and accepted evidence locations.
- Source provenance, validation evidence, disclosure artifacts, and release/split membership. Keep evaluator labels outside scanner inputs.

**Same CWE, repository, or file is a duplicate-review signal, not proof of redundancy.** Direct SQL construction and a cross-file query-builder failure can test different capabilities. Conversely, several CVEs can describe versions of the same flaw. Group true variants; permit independent replications only with a stated purpose and release quota. The validator should reject duplicate target/artifact records and require justification for repeated signatures. Do not predict a “60–80 case” corpus before review.

Freeze a coverage matrix and family weights per release. Report distinct families, targets, and repositories separately. Harvest missing meaningful coverage, not arbitrary Cartesian combinations or whichever project has the most advisories. Annotate input source types, including model output where relevant; source-type performance differences remain observational, not causal proof.

### Ground truth and fixed controls

Keep **origin** separate from **validation**: advisory plus maintainer fix, maintainer fix without advisory, independently reviewed internal finding, or synthetic fixture. A CVE is neither required nor sufficient.

Use cumulative validation levels:

- **V1:** artifacts, hashes, paths, and patch/remapping bookkeeping verified.
- **V2:** affected code parses and structural changes are reviewed. Type-checking may require dependencies.
- **V3:** independent review establishes the claimed target label. Fixed/safe controls additionally require a targeted regression or independently checked security invariant. Accepting a positive label does not require having a fixed pair.
- **V4:** V3 plus the relevant build and broader tests.

Strong detection/fixed-control claims require V3 or V4 for their respective labels. Lower-tier candidates remain visible but outside those headline denominators. Record unavailable/failed validation and resulting selection bias. Full test success alone does not establish the target was fixed; exploit reproduction is not required. LLM self-review or agreement between scanners is not ground truth.

Use the actual fixed snapshot when suitable. Backport only when needed to isolate unrelated changes, and validate the result. Backporting improves experimental control; it does not guarantee novelty or eliminate memorization. Map targets through changed symbols, paths, guards, and deleted/moved code—not just shifted line numbers.

Curate real intentional-capability negatives with explicit authority and guard assumptions. A subprocess or filesystem call is not unsafe merely because it is powerful; intentional use is not automatically safe either. A repaired snapshot is negative only for the validated root cause, not for the whole repository.

## 4. Scoring and review

Score the union of known targets applicable to each scanned input. A root cause earns detection credit once; locations and evidence regions do not create extra vulnerabilities. Retain duplicates as a separate burden metric.

Use conservative, versioned matching rules with accepted alternative locations. Preserve ambiguous matches for review. Neither a CVE mention nor a whole-file span should automatically earn target credit. Silence establishes a negative result only after a valid completed scan; errors and unsupported inputs are not correct negatives.

| Measurement | Definition / boundary |
|---|---|
| Known-target hit rate | Unique accepted targets detected / assigned accepted targets. Show operational failures and a separate completed-scan diagnostic; do not silently remove unsupported work to improve rankings. |
| Pair correctness | Target detected in affected code and not incorrectly alleged in its validated fixed counterpart. Show both-flagged, both-silent, reversed, and unavailable pairs. |
| Capability-safe FP rate | Validated safe controls falsely flagged / validated safe controls in completed scans. Show assigned and completed counts; no completed controls means N/A, not 0%. |
| Mixed-intent correctness | Detect the target while avoiding the annotated safe-capability allegation in the same input. |
| Alert usefulness and burden | Resolved-review precision with unresolved fraction/bounds, total delivered alerts, duplicates, and measured review effort. |
| Operational fit | Completion/coverage, full-scan and PR latency, resource/API usage, and separately reported license costs. Unknown cost is not zero. |
| Complementary value | Additional confirmed targets beyond a named baseline, together with additional alert/review burden. |

The primary detection score averages repetitions **within each target**, then applies frozen target weights:

$$
\widehat D_s = \sum_{i=1}^{N} w_i\left(\frac{1}{k_i}\sum_{r=1}^{k_i}Y_{sir}\right),
\qquad \sum_i w_i=1.
$$

Here, $Y_{sir}$ is a verified target hit by system $s$ in repetition $r$; duplicate findings cannot increase it. Equal-target weighting uses $w_i=1/N$. Keep assigned failures in the operational denominator. [The math specification](EVALUATION_MATH.md#1-target-detection-and-paired-comparisons) also defines project-balanced weights, pair scores, safe-control denominators, and paired differences.

Unmatched findings remain **unreviewed**, not false positive. Review can establish additional security findings, false alarms, or unresolved claims. Keep out-of-scope findings distinct. A valid new issue is not retroactively added to one tool's recall denominator; version the labels and rescore comparable stored outputs for all tools.

Sample normalized unique claims across tools, projects, and finding types using recorded selection probabilities; count delivered duplicates separately as burden. For published estimates, use two independent reviewers with adjudication, blinded to tool identity where feasible; report agreement, unresolved cases, sampling weights, and uncertainty. Fifty to one hundred findings per tool is a possible pilot budget, not a universal sufficient sample. Include ordinary snapshots/PRs: CVE-selected inputs do not establish everyday precision, and ordinary changes are not presumed safe. [NIST SATE's production-warning review](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.500-326.pdf) is a methodological precedent.

**Unknowns must not be free in the engineering loop.** Constrain total delivered alerts and review effort, including duplicates and unresolved findings. Estimate review cost from review time; an estimated FP fraction is not a review-time estimate or permission to relabel unknowns. Freeze the penalty/budget policy before optimization.

## 5. Minimum engine

Keep these as separable modules, not separate services:

1. **Corpus/release planner:** immutable release lists, accepted targets/controls, variant families, split manifests, and selected workload. Keep case admission independent of tool performance.
2. **Materializer:** immutable source cache; fresh trial export; input-tree hashes and transformation manifests; pinned dependency preparation before evaluation. Exclude benchmark metadata, parent-directory configuration, and cross-trial memory. Remove `.git` from controlled full scans; expose only the supplied base/head history if PR tooling needs Git. Audit answer-bearing artifacts and document any scrubbing. Preserve ordinary project identity/domain context; identity rewriting is a separate experiment.
3. **Executor:** sanitized runtime request, declared language scope, limits, explicit success/partial/unsupported/error/timeout states, and isolated trial state. Use source read-only plus writable build/output areas where supported; handle compatibility exceptions explicitly. Enforce filesystem/egress policy outside tool hooks. Deterministic scanners can also execute untrusted build machinery; export alone is not isolation.
4. **Importer/normalizer:** accept SARIF and native JSON; preserve raw findings, messages, locations, related locations, and flow evidence. Centralize auditable mappings keyed by tool/rule/version, with cautious CWE fallbacks. Do not discard unmapped output or invent precise locations.
5. **Pure scorer:** consume stored predictions plus evaluator-only labels. Re-score without rerunning scanners. Separate execution status, target matching, review status, and duplicate status.
6. **Reporter/review queue:** scorecard, coverage matrix, per-family/project breakdowns, trace availability, review sampling, and dataset corrections. Distinguish independently executed runs from unverified vendor submissions.

Execution identity includes the exact input tree or PR base/head pair, scan root, language scope, condition, environment, scanner configuration, tool/network contract, budget, and repetition ID. Reuse an output across applicable cases only when these match. Never replace independent repetitions with cached predictions.

Record actual tool/edition/model identity, immutable model or weight revision when available, requested-versus-observed identity, ruleset hash/date, configuration and environment hashes, seeds/settings, timing, tokens, retries, and measured/estimated costs. Separate setup/indexing cost from scanning and declare cold/warm cache policy. Reject known model mismatches; mark unverifiable provenance explicitly. Pin rules before scanning rather than using a moving registry alias.

For PR mode, validate **target-clean base → target-vulnerable head** separately from the remediation pair. Keep native PR review and synthesized dual-scan results labeled. Preserve necessary unchanged context and remap findings through edits; changed-line-only matching can miss cross-file effects or manufacture alert churn.

## 6. Freshness, statistics, and the improvement loop

### Keep inexpensive contamination controls in v1

- Store earliest **known public answer-bearing** artifacts and their date sources. A Git timestamp is not first-publication evidence; a fix may legitimately follow an advisory. Flag uncertainty rather than enforce a universal fix-before-advisory rule.
- With credible horizon `H` and observed-model cutoff `C`, classify `H > C` as `cutoff-eligible`, `H <= C` as `cutoff-ineligible`, and insufficient provenance as `cutoff-unknown`. Use `not_applicable` where this model-cutoff test does not apply. Public synthetic examples are not inherently immune to exposure.
- Preserve labels/results and apply freshness filters at reporting time. Budgeted execution may select a slice without erasing the rest of the corpus. For comparisons, use the same case set; do not rank model-specific denominators as equivalent.
- Show both current-product performance and a common freshness-restricted slice where provenance permits. Rule-pack dates describe provenance, not a training cutoff. Current tools may legitimately encode known fixes; freshness answers an additional generalization question.
- Offline workspace controls cannot certify a remote provider's training history or internal retrieval. A new GHSA, a 90-day window, or a cutoff buffer does not make a case clean by construction. Missing dates remain unknown.

### Repeats and uncertainty

Pilot stochastic systems on a diverse subset, initially around 8–10 cases at three repetitions if affordable. Estimate variance, failures, review load, and cost; simulate the cases/repetitions needed for a declared effect size or interval width. Do not inherit fixed `k=5`/`k=10` claims from the old notes.

Use one accuracy run for a demonstrably deterministic pinned configuration; timing variability may still need repeats. Pair system comparisons on the same inputs and policies. Account for repository/family clustering; show per-project results and leave-one-project-out sensitivity when cluster counts are small. Repeated scans are not independent new vulnerabilities.

Report mean per-run detection and variability. “Found at least once” and “found every time” are optional reliability views with explicit repetition counts, not substitutes for deployment performance. Use measured cost/quality tradeoffs; do not assume LLM tools cost 100× more.

[Sample-size and reliability formulas](EVALUATION_MATH.md#4-how-many-cases-and-repetitions) distinguish run noise from variation across cases. They do not produce a universal repetition count or make this convenience corpus representative of all software.

### Bounded development loop

1. Freeze evaluator version, accepted development cases, scoring policy, and regression budgets.
2. Evaluate a baseline; expose development failure categories and review feedback.
3. Change the SAST implementation/configuration, then compare on the same development contract.
4. Promote only if detection gains meet false-alarm, review-load, completion, and cost constraints.
5. Evaluate releases on protected repository-held-out and later-case sets with limited feedback.

The engineering agent must not edit expected answers, the evaluator, or protected inputs. Keep related copies/variants together across splits. Case-random splits are insufficient for cross-project claims. Leave-one-repository-out folds repeatedly used for tuning are validation, not an untouched final holdout. Public holdout code can still be familiar to a foundation model.

Human acceptance of new labels remains necessary. Feed reviewed development findings back into the suite; keep protected findings from leaking through debugging logs or per-case feedback.

## 7. Other ideas: retain with explicit priority and limits

These are choices after the v1 foundation, not prerequisites bundled into it.

The [research equations](EVALUATION_MATH.md#7-contamination-and-grounding-research-only) retain the earlier identity, triple-difference, and exposure ideas without interpreting their values as percentages of memorization.

| Idea | Recommendation and tradeoff |
|---|---|
| Harmless-edit controls | First follow-on diagnostic on real pairs: affected/fixed, each with the same validated harmless edit. Measure correctness and alert stability, separating location drift from changed allegations. Additional validation and scans are required. |
| Rolling advisory ingestion | Reuse existing candidate-generation/date-backfill tools; prioritize coverage gaps, require reviewer admission, then freeze releases. Reserve later cases for evaluation. Neither new ground truth nor a clean holdout arrives “for free.” |
| Historical / pre-disclosure detection | Separate research track. Reconstruct the whole historical tool stack, not old rules with a current engine/model. A current retrospective hit plus cutoff gating does not establish an actual pre-disclosure detection; prospective timestamped runs support stronger claims. |
| SZZ introducing-commit candidates | Optional curation aid. Blame identifies candidates, not a validated introduction. Review every accepted boundary, including single-commit candidates; multi-commit/configuration changes can defeat the heuristic. No promised expansion to all 189 cases. |
| Unknown findings as new cases | Accept independently confirmed issues into a versioned corpus. Handle genuinely new issues through a separately approved disclosure process; benchmark execution must not automatically publish or contact maintainers. |
| Guard-removal mutations | Defer. Mutated real repositories are still synthetic cases; reachability and other guards can invalidate the assumed label. No automatic exact-ground-truth claim and no mixing into disclosed-case scores. |
| Autofix quality | Separate future task on validated cases. Require target-specific checks and preserved functionality; similarity to the maintainer patch or silence from the same scanner is insufficient. |
| Identity-only / post-scoring probes | Optional offline audit, independent of scored sessions. Blind repo/version and targeted-path probes test available advisory knowledge; a post-report elicitation measures something different. Validate associations and allow other valid advisories. Positive temporal anomalies trigger investigation; negative recall proves little. |
| Original / pseudonymous / strongly renamed pairs | Research subset only. Preserve domain context in the middle condition; use matched maps and language-aware validation. Import paths, reflection, tokenization, and task difficulty can change. Neither success nor failure isolates memory. Six basic conditions cost six scans per repetition before additional variants/probes. |
| Popularity/exposure and triple differences | Exploratory aggregate analysis. Separate code familiarity from answer-bearing exposure; stars do not reproduce Roberts's item-frequency measure. Test interactions directly with project/difficulty controls. Current search frequency is not historical training exposure; post-cutoff identity benefit is not automatically a clean context baseline. |
| Tool/file/web traces and grounding | Preserve optional trace sidecars; distinguish system-access from model-visible content. A blocked request proves neither memory nor successful retrieval. Use matched web-enabled/offline repeats to assess retrieval assistance. Report evidence coverage and citation precision separately from correctness; never require opening every annotated file. Complete-flow credit needs explicit flow/security-decision annotations and still does not reveal internal reasoning. |
| Context bundles / missing decisive evidence | Diagnostic only: distinguish navigation/context-selection failures from assessment failures, and test justified uncertainty. Curators must establish sufficiency or genuine ambiguity; reduced context changes the task. |
| Controlled training exposure / private generated applications | Defer outside the buyer benchmark. Useful possible calibration research, with substantial creation, validation, and training cost. Keep existing tiny synthetic cases for scorer/adapter diagnostics. |
| CVE instructions embedded in source | Reject for scored runs: they prime the answer, test instruction compliance, and modify inputs. Passive correct-ID mentions may be audited, but do not determine detection credit. |
| A single “memory vs reasoning” verdict | Reject. Use observable flags and separately justified cross-run contrasts if attribution research is undertaken. Knowledge, retrieval, and analysis can coexist. |

## 8. Packaging options and deliverables

**Recommendation: a standalone core and CLI, an optional Inspect integration, and pinned scanner-environment images.** Publish versioned corpus releases separately. This serves local CI, commercial-product imports, and model research without making every user adopt an agent framework. The following interfaces are proposed, not implemented; the existing [pyproject.toml](../pyproject.toml) is only a starting point.

| Packaging option | Where it fits | Tradeoff / decision |
|---|---|---|
| Python package + CLI/SDK | Buyers, CI, SAST builders, custom harnesses | **Primary interface.** Small install; pure scoring needs no model API or Inspect. We maintain execution and adapter contracts. |
| Inspect-first task package | Primarily model/agent evaluation | Less custom agent orchestration, but couples all users to Inspect conventions. **Use as an optional integration**, not the only way to run or score. |
| Container-only distribution | Teams needing reproducible scanner/toolchain environments | Larger downloads, architecture/licensing constraints, and awkward library use. **Ship pinned images where useful**, not one giant image containing every scanner and repository. Images alone do not enforce runtime policy. |
| Prediction-bundle import | SaaS tools, vendor submissions, existing CI scanners | **First-class path:** SARIF/native JSON plus input/configuration provenance, scored locally. It cannot independently verify how a vendor executed a scan. |
| Hosted evaluation service / leaderboard | Central review and protected evaluation at larger scale | Adds operations, private-code handling, access control, and submission-abuse costs. **Defer**; start with downloadable reports and an evaluator-owned holdout process. |

These are complementary distribution layers, not five engines. The Python distribution follows ordinary [wheel/source-package conventions](https://packaging.python.org/en/latest/tutorials/packaging-projects/); scanner images use the [OCI image format](https://github.com/opencontainers/image-spec). Keep large source snapshots, proprietary tools, API credentials, and protected labels out of the wheel. Provide hash-checked preparation recipes or licensed archives for corpus assets. Public development labels and protected release labels need separate distribution rules.

### What to reuse from Inspect

Inspect supports distributing named tasks, solvers, and scorers through Python packages and registered entry points. That is a good extension mechanism for SASTbench, not a reason to rebuild Inspect. [Inspect component packaging](https://inspect.aisi.org.uk/extensions-components.html).

- **Task:** select a frozen release, full/PR workflow, and comparison contract.
- **Sample:** one unique scan input/scope/condition; use epochs for independent repetitions, not one rescan per CVE. Inspect exposes [epochs and task controls](https://inspect.aisi.org.uk/tasks.html).
- **Solver:** a selected SAST system adapter or fixed model-evaluation harness. Model changes do not silently change the harness.
- **Scorer:** call the same evaluator-owned pure scorer used by CLI/import workflows. Aggregate by target/family weights, not an unweighted mean of scan samples.
- **Logs/viewer:** preserve native logs and export the common result bundle. External products may expose only their outputs; do not imply complete internal traces. Inspect already supplies [logs and a viewer](https://inspect.aisi.org.uk/eval-logs.html).

Two integration checks are mandatory. First, an Inspect sandbox does not restrict host-side tools or the provider; custom Compose replaces generated network settings, so verify the full evaluation policy. [Sandbox boundaries](https://inspect.aisi.org.uk/sandboxing.html). Second, logs can include sample targets and scores: protected answers must stay evaluator-side, and shared logs must be checked/redacted. [Log schema](https://inspect.aisi.org.uk/eval-logs.html#log-schema). A `target` field is not an access-control boundary.

Pin a tested Inspect version in reproduction environments. Keep its integration thin; if the spike fails, the standalone benchmark still ships. A static documentation site with quickstarts, adapter examples, and downloadable reports provides the useful “packaged like Inspect” experience without a hosted platform.

### Concrete deliverables

| Deliverable | Acceptance check |
|---|---|
| **D1 — Core wheel, CLI, and Python API** | Validate/plan/run/import/score/report interfaces; clean-install smoke test; stored outputs score offline without Inspect. |
| **D2 — Versioned corpus release** | Frozen IDs, coverage/families, split manifests, provenance, validation records, input hashes, and preparation recipes; protected labels excluded from public artifacts. |
| **D3 — Adapter SDK and integrations** | SARIF/native-JSON import, one pinned CLI scanner, one LLM-backed configuration, and the Inspect integration spike. Shared conformance tests distinguish empty success, partial output, unsupported work, and errors. |
| **D4 — Reproduction environments and run bundle** | Pinned dependencies/images where needed; manifests, raw/normalized predictions, status, usage, available traces, and scores. All shipped execution/import paths give identical target scores for identical fixture outputs. |
| **D5 — Buyer report and review pack** | HTML plus CSV/JSON scorecards, review sample/adjudication records, metric denominators, uncertainty, cost, and real safe-control results—or explicit N/A. |
| **D6 — Bounded development gate** | Baseline/candidate comparisons with frozen constraints; protected evaluation isolated from development feedback. No evaluator or label changes by the engineering agent. |
| **D7 — Documentation and worked examples** | Installation, one local scanner run, one model/harness run, one imported-output evaluation, adapter/case-author guides, cited methods, and an offline score-replay example. |

Version the **engine, corpus, scorer, and system configuration independently** in every result. Release D1–D4 first as a pilot; the buyer-facing v1 needs reviewed real positive/fixed/safe coverage and D5–D7. A successful package install or polished leaderboard is not the benchmark's validation criterion.

## 9. Reuse, implementation order, and decisions

**Reuse selectively.** SARIF is an interchange format, not an execution or correctness oracle. Keep native JSON and a framework-independent scorer; test the Inspect integration before committing to its maintenance.

[OpenSSF CVE Benchmark](https://github.com/ossf-cve-benchmark/ossf-cve-benchmark) already evaluates affected/patched real code; [CWE-Bench-Java](https://github.com/iris-sast/cwe-bench-java) provides advisory, commit, and reviewed location metadata. These are direct prior art. Keep the discussion's other reuse leads—SWE-bench release/prediction separation, CyberGym/ExploitGym packaging and isolation, PrimeVul pair reporting, and OWASP diagnostics—as bounded integration investigations. Do not import exploitation tasks/oracles into the SAST objective, claim another project's maintenance history explains its design, or declare a framework choice settled without a compatibility check.

Implement in four reviewable milestones:

1. **Correctness contract:** define target/variant/finding states and metric denominators; add regression tests for duplicates, shared snapshots, unknowns, coarse locations, errors, and missing dates. Establish the sanitized runtime interface. These tests need output fixtures, not new application repositories.
2. **Small end-to-end release slice:** migrate representative real cases, add real safe controls and validated fixed pairs, group execution correctly, isolate inputs, and retain replayable predictions with pinned provenance. Demonstrate a CLI scanner and an LLM-backed system under declared profiles.
3. **Buyer report:** sampled two-reviewer adjudication, repeated-run pilot, coverage/uncertainty/cost reporting, and validated PR support. Correct the README and adapter guidance alongside behavior. Replace the count-driven release bar with approved coverage, validation, and contract checks.
4. **Improvement loop:** freeze development and protected release splits; enable bounded candidate comparisons and release gates. Add the follow-on diagnostics only after this works.

An internal schema/runner rewrite is reasonable; preserve legacy cases, raw results, and ingestion utilities through explicit migration. New scoring changes invalidate direct comparison with old headline scores. A complete corpus ontology or a large framework migration should not block the first correct vertical slice.

Before publication, verify dataset redistribution and named-result publication permissions for the actual licenses/agreements; do not assume anonymization resolves restrictions. Resolve the naming collision with the published [SastBench triage benchmark](https://arxiv.org/abs/2601.02941). Position this project around agentic-application detection and guard-aware evaluation without unsupported “first,” “only,” “zero-day,” or contamination-free claims.

**Owner decisions before implementation:**

- [ ] Approve agentic-application scope, six-kind initial coverage, and separate product/model comparison contracts.
- [ ] Select first product editions/model snapshots and realistic scan/review budgets; choose which network profiles must ship.
- [ ] Assign case-validation and finding-review capacity; approve release coverage and protected-project splits before seeing comparative scores.
- [ ] Approve standalone core + optional Inspect + selective container images, or choose a different primary packaging option.
- [ ] Approve milestone 1, then review the vertical slice and Inspect spike before committing to a broader rebuild.
